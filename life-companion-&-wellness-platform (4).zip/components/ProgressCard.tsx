import React from 'react';
import { UserProfile } from '@/types';
import { XP_PER_LEVEL } from '@/constants';
import { StarIcon } from './icons/Icons';

interface ProgressCardProps {
  profile: UserProfile;
}

export const ProgressCard: React.FC<ProgressCardProps> = ({ profile }) => {
  const progressPercentage = (profile.xp / XP_PER_LEVEL) * 100;

  return (
    <div className="bg-gray-800 p-6 border border-gray-700">
      <div className="flex justify-between items-center mb-4">
        <div>
          <p className="text-sm text-gray-400">Level</p>
          <p className="text-3xl font-bold text-white">{profile.level}</p>
        </div>
        <div className="text-right">
           <p className="text-sm text-gray-400">Gold</p>
           <div className="flex items-center gap-1">
             <StarIcon className="w-6 h-6 text-yellow-400" />
             <p className="text-2xl font-bold text-white">{profile.gold}</p>
           </div>
        </div>
      </div>
      <div>
        <div className="flex justify-between items-baseline mb-1">
          <p className="text-sm font-medium text-gray-300">Level Progress</p>
          <p className="text-xs text-gray-400">{profile.xp} / {XP_PER_LEVEL} XP</p>
        </div>
        <div className="w-full bg-gray-700 h-2">
          <div
            className="bg-blue-500 h-2 transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};