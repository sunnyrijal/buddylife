import React, { useState } from 'react';
import { Mood } from '@/types';
import { MOODS } from '@/constants';

interface MoodDropdownProps {
  selectedMood: Mood | null;
  onSelectMood: (mood: Mood) => void;
}

export const MoodDropdown: React.FC<MoodDropdownProps> = ({ selectedMood, onSelectMood }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleSelect = (mood: Mood) => {
    onSelectMood(mood);
    setIsOpen(false);
  };

  const selectedMoodData = MOODS.find(m => m.name === selectedMood);

  return (
    <div className="relative w-full">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between bg-gray-700 border border-gray-600 px-4 py-3 text-left focus:outline-none focus:ring-2 focus:ring-blue-500"
      >
        {selectedMoodData ? (
          <div className="flex items-center gap-2">
            <span className="text-xl">{selectedMoodData.icon}</span>
            <span className={`font-semibold ${selectedMoodData.color}`}>{selectedMoodData.name}</span>
          </div>
        ) : (
          <span className="text-gray-400">How are you feeling?</span>
        )}
        <svg className={`w-5 h-5 text-gray-400 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
      </button>

      {isOpen && (
        <div className="absolute z-10 mt-1 w-full bg-gray-800 border border-gray-700 shadow-lg max-h-60 overflow-y-auto">
          {MOODS.map(mood => (
            <div
              key={mood.name}
              onClick={() => handleSelect(mood.name)}
              className="flex items-center gap-3 px-4 py-3 cursor-pointer hover:bg-gray-700"
            >
              <span className="text-xl">{mood.icon}</span>
              <span className={`font-medium ${mood.color}`}>{mood.name}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};