import React from 'react';
import { XIcon, SpotifyIcon } from './icons/Icons';

interface SpotifyConnectModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: () => void;
}

export const SpotifyConnectModal: React.FC<SpotifyConnectModalProps> = ({ isOpen, onClose, onConnect }) => {
  if (!isOpen) return null;

  const handleConnect = () => {
    onConnect();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 shadow-xl w-full max-w-md p-6 relative border border-gray-700">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
          <XIcon className="w-6 h-6" />
        </button>
        <div className="text-center">
            <SpotifyIcon className="w-12 h-12 text-[#1DB954] mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white">Connect Your Spotify Account</h2>
            <p className="text-gray-300 mt-2 mb-6">
                By connecting your Spotify account, you allow us to provide personalized music and podcast suggestions based on your profile and hobbies.
            </p>
        </div>
        <div className="flex flex-col gap-3">
          <button 
            onClick={handleConnect} 
            className="w-full px-4 py-3 bg-[#1DB954] text-white font-semibold hover:bg-[#1ED760] transition-colors"
          >
            Authorize & Connect
          </button>
          <button onClick={onClose} className="w-full px-4 py-2 bg-gray-700 text-gray-200 font-semibold">
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};