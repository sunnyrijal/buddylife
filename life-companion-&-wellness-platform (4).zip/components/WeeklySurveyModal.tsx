import React, { useState } from 'react';
import { WeeklySurvey, SurveyQuestion } from '@/types';
import { LoaderIcon, XIcon } from './icons/Icons';

interface WeeklySurveyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (answers: Record<string, string>) => void;
  survey: WeeklySurvey | null;
  isLoading: boolean;
}

export const WeeklySurveyModal: React.FC<WeeklySurveyModalProps> = ({ isOpen, onClose, onSubmit, survey, isLoading }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});

  if (!isOpen || !survey) return null;

  const handleAnswerSelect = (question: string, option: string) => {
    setAnswers(prev => ({ ...prev, [question]: option }));
    // Automatically move to next step after selection
    if (currentStep < survey.questions.length - 1) {
        setTimeout(() => setCurrentStep(s => s + 1), 300);
    }
  };

  const handleSubmit = () => {
    onSubmit(answers);
  };

  const currentQuestion: SurveyQuestion | undefined = survey.questions[currentStep];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 shadow-2xl w-full max-w-lg p-6 relative border border-gray-700">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
          <XIcon className="w-6 h-6" />
        </button>
        <div className="text-center">
            <h2 className="text-2xl font-bold text-white">Weekly Check-in</h2>
            <p className="text-gray-300 mt-1">Help us get to know you better!</p>
        </div>

        <div className="w-full bg-gray-700 h-2 my-4">
          <div className="bg-blue-500 h-2 transition-all duration-300" style={{ width: `${((currentStep + 1) / survey.questions.length) * 100}%` }}></div>
        </div>

        {currentQuestion && (
             <div className="mt-6 min-h-[200px]">
                <p className="text-lg font-semibold text-gray-200 text-center">{currentQuestion.question}</p>
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                    {currentQuestion.options.map(option => (
                        <button
                            key={option}
                            onClick={() => handleAnswerSelect(currentQuestion.question, option)}
                            className={`p-4 text-left w-full transition-colors border-2 ${answers[currentQuestion.question] === option ? 'bg-blue-900/50 border-blue-500 text-blue-300' : 'bg-gray-700 border-gray-600 hover:border-blue-500'}`}
                        >
                            {option}
                        </button>
                    ))}
                </div>
            </div>
        )}
        
        <div className="flex justify-between items-center mt-6">
            <p className="text-sm text-gray-400">{currentStep + 1} / {survey.questions.length}</p>
            
            {currentStep === survey.questions.length - 1 && (
                <button onClick={handleSubmit} disabled={isLoading || !answers[currentQuestion.question]} className="px-6 py-2 bg-green-600 text-white font-bold flex items-center gap-2 disabled:bg-green-800">
                    {isLoading ? <LoaderIcon className="w-5 h-5" /> : null}
                    Submit
                </button>
            )}
        </div>
      </div>
    </div>
  );
};