import React, { useState } from 'react';
import { XIcon, LoaderIcon } from './icons/Icons';

interface BulkInventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (text: string) => void;
  isLoading: boolean;
}

export const BulkInventoryModal: React.FC<BulkInventoryModalProps> = ({ isOpen, onClose, onConfirm, isLoading }) => {
  const [text, setText] = useState('');

  if (!isOpen) return null;

  const handleConfirm = () => {
    if(text.trim()){
      onConfirm(text);
      setText('');
      onClose();
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 shadow-xl w-full max-w-lg p-6 relative border border-gray-700">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
          <XIcon className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-bold text-white mb-2">Add Items in Bulk</h2>
        <p className="text-gray-300 mb-4">
          Enter a list of items, hobbies, or subscriptions below. Our AI will automatically categorize them for you.
          For example: "Netflix, running shoes, a book about dragons, my dog, coffee subscription".
        </p>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          rows={6}
          className="w-full bg-gray-700 border border-gray-600 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
          placeholder="Enter items here..."
        />
        <div className="flex justify-end gap-4 mt-4">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-600 text-gray-200 font-semibold hover:bg-gray-500 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleConfirm}
            disabled={isLoading || !text.trim()}
            className="px-4 py-2 bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-colors flex items-center gap-2 disabled:bg-blue-800"
          >
            {isLoading ? <LoaderIcon className="w-5 h-5" /> : null}
            Process Items
          </button>
        </div>
      </div>
    </div>
  );
};