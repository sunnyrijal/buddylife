import React from 'react';
import { XIcon, StarIcon, CheckCircleIcon } from './icons/Icons';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgrade: (tier: 'Premium') => void;
}

const premiumFeatures = [
    "Unlimited AI Chat",
    "Advanced AI Suggestions",
    "Partner Sync Features",
    "Cloud Data Backup",
    "Exclusive Themes & Icons",
    "Priority Support"
];

export const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose, onUpgrade }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 border border-gray-700 shadow-2xl w-full max-w-md p-6 relative">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
          <XIcon className="w-6 h-6" />
        </button>
        <div className="text-center">
            <div className="mx-auto flex items-center justify-center h-12 w-12 bg-gray-700">
                 <StarIcon className="h-6 w-6 text-blue-400" />
            </div>
            <h2 className="text-2xl font-bold text-white mt-4">Go Premium</h2>
            <p className="text-gray-300 mt-2">Unlock all features and supercharge your wellness journey.</p>
        </div>
        
        <div className="mt-6 space-y-4">
            {premiumFeatures.map(feature => (
                <div key={feature} className="flex items-center gap-3">
                    <CheckCircleIcon className="w-5 h-5 text-blue-400"/>
                    <span className="text-gray-200">{feature}</span>
                </div>
            ))}
        </div>

        <div className="mt-8 space-y-4">
            <button
              onClick={() => onUpgrade('Premium')}
              className="w-full text-center px-4 py-3 bg-blue-600 text-white font-bold hover:bg-blue-700 transition-colors"
            >
              Upgrade Now - $49.99/year
            </button>
             <button
              onClick={() => onUpgrade('Premium')}
              className="w-full text-center px-4 py-3 bg-gray-700 text-gray-100 font-semibold hover:bg-gray-600 transition-colors"
            >
              $4.99/month
            </button>
        </div>
      </div>
    </div>
  );
};