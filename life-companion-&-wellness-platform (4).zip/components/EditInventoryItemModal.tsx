import React, { useState, useEffect } from 'react';
import { InventoryItem, InventoryCategory, InterestLevel } from '@/types';
import { XIcon } from './icons/Icons';

interface EditInventoryItemModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (item: InventoryItem) => void;
  item: InventoryItem | null;
}

export const EditInventoryItemModal: React.FC<EditInventoryItemModalProps> = ({ isOpen, onClose, onSave, item }) => {
  const [editedItem, setEditedItem] = useState<InventoryItem | null>(item);

  useEffect(() => {
    setEditedItem(item);
  }, [item]);

  if (!isOpen || !editedItem) return null;

  const handleSave = () => {
    if (editedItem) {
      onSave(editedItem);
      onClose();
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setEditedItem(prev => prev ? { ...prev, [name]: value } : null);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 shadow-xl w-full max-w-lg p-6 relative border border-gray-700">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
          <XIcon className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-bold text-white mb-4">Edit Item</h2>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300">Name</label>
            <input
              type="text"
              name="name"
              value={editedItem.name}
              onChange={handleChange}
              className="mt-1 block w-full bg-gray-700 border border-gray-600 p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Description</label>
            <textarea
              name="description"
              value={editedItem.description}
              onChange={handleChange}
              rows={3}
              className="mt-1 block w-full bg-gray-700 border border-gray-600 p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Category</label>
            <select name="category" value={editedItem.category} onChange={handleChange} className="mt-1 block w-full bg-gray-700 border border-gray-600 p-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
              {Object.values(InventoryCategory).map(cat => <option key={cat} value={cat}>{cat}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-300">Interest Level</label>
            <select name="interest" value={editedItem.interest} onChange={handleChange} className="mt-1 block w-full bg-gray-700 border border-gray-600 p-2 focus:outline-none focus:ring-2 focus:ring-blue-500">
               {Object.values(InterestLevel).map(lvl => <option key={lvl} value={lvl}>{lvl}</option>)}
            </select>
          </div>
        </div>
        <div className="flex justify-end gap-4 mt-6">
          <button onClick={onClose} className="px-4 py-2 bg-gray-600 font-semibold">Cancel</button>
          <button onClick={handleSave} className="px-4 py-2 bg-blue-600 text-white font-semibold hover:bg-blue-700">Save Changes</button>
        </div>
      </div>
    </div>
  );
};