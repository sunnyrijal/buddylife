import { AppState, Mood, SocialContext, RelationshipStatus, TimeAvailability, Achievement } from './types';

export const XP_PER_LEVEL = 1000;
export const XP_REWARDS = {
    HABIT_EASY: 10,
    HABIT_MEDIUM: 25,
    HABIT_HARD: 50,
    NUDGE: 5,
    DAILY_REFRESH: 25,
};

export const MOODS: { name: Mood; color: string; icon: string }[] = [
    { name: Mood.Energized, color: 'text-blue-400', icon: '⚡️' },
    { name: Mood.Focused, color: 'text-blue-400', icon: '🎯' },
    { name: Mood.Balanced, color: 'text-blue-400', icon: '⚖️' },
    { name: Mood.Creative, color: 'text-blue-400', icon: '🎨' },
    { name: Mood.Social, color: 'text-blue-400', icon: '👥' },
    { name: Mood.Tired, color: 'text-blue-400', icon: '😴' },
    { name: Mood.Bored, color: 'text-blue-400', icon: '😑' },
    { name: Mood.Anxious, color: 'text-blue-400', icon: '😟' },
    { name: Mood.Motivated, color: 'text-blue-400', icon: '🔥' },
    { name: Mood.Reflective, color: 'text-blue-400', icon: '🤔' },
];

export const ACHIEVEMENTS: Achievement[] = [
    { id: 'HABIT_STARTER', name: 'Habit Starter', description: 'Complete your first habit.', xp: 50, gold: 5 },
    { id: 'WEEK_WARRIOR', name: 'Week Warrior', description: 'Maintain a 7-day streak on any habit.', xp: 100, gold: 10 },
    { id: 'LEVEL_UP', name: 'Level Up!', description: 'Reach level 5.', xp: 150, gold: 15 },
    { id: 'COLLECTOR', name: 'Collector', description: 'Add 10 items to your inventory.', xp: 50, gold: 5 },
    { id: 'CONVERSATIONALIST', name: 'Conversationalist', description: 'Send 10 messages to the AI companion.', xp: 50, gold: 5 },
];

const getTrialEndDate = (): string => {
    const date = new Date();
    date.setDate(date.getDate() + 30);
    return date.toISOString();
}

export const INITIAL_APP_STATE: AppState = {
    userProfile: {
        isLoggedIn: false,
        username: null,
        onboardingCompleted: false,
        subscriptionTier: 'Free',
        trialEndDate: getTrialEndDate(),
        level: 1,
        xp: 0,
        gold: 0,
        streakFreezes: 1,
        relationshipStatus: RelationshipStatus.Single,
        partnerUsername: null,
        friendUsernames: [],
        preferences: {
            enableNotifications: true,
            enableHabitReminders: true,
        },
        achievements: [],
        lastSurveyDate: null,
        isSpotifyLinked: false,
    },
    habits: [],
    hobbies: [],
    inventory: [],
    commitments: [],
    aspirations: [],
    chatHistory: [
        {
            id: 'initial-ai-message',
            sender: 'ai',
            text: "Hello! I'm your life companion. How are you feeling today? Try voice mode in the chat!",
            timestamp: new Date().toISOString(),
        }
    ],
    currentMood: null,
    socialContext: SocialContext.JustMe,
    currentTimeAvailability: null,
    isDateNightMode: false,
    inventorySuggestions: [],
    externalContentSuggestions: [],
    localActivitySuggestions: [],
    dailyRefresh: null,
    isLoading: false,
    error: null,
    activeScreen: 'Today',
    isSurveyDue: true,
    currentWeeklySurvey: null,
    voiceSession: null,
    isVoiceSessionActive: false,
    currentTranscription: {
        input: '',
        output: '',
    },
    sharedContext: {
        partner: null,
        friends: [],
    },
    hobbyToDetail: null,
};