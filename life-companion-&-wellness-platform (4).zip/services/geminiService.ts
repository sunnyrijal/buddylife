import { GoogleGenAI, Type, LiveSession, LiveServerMessage, Modality } from "@google/genai";
import { InventoryCategory, InterestLevel, Mood, SocialContext, ChatMessage, UserProfile, InventoryItem, Suggestion, TimeAvailability, AppState, SharedContext, SurveyQuestion } from "@/types";

if (!process.env.API_KEY) {
    throw new Error("Missing Gemini API key. Please set it in your .env file.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const inventorySchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            name: { type: Type.STRING },
            category: { type: Type.STRING, enum: Object.values(InventoryCategory) },
            confidence: { type: Type.NUMBER, description: 'A score from 0.1 to 1.0 of how confident you are about the categorization.' },
            interest: { type: Type.STRING, enum: Object.values(InterestLevel), description: 'Guess the user\'s interest level in this item.' },
            description: { type: Type.STRING, description: 'A brief, one-sentence description.' },
        },
        required: ["name", "category", "confidence", "interest", "description"],
    },
};

const suggestionsSchema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            title: { type: Type.STRING },
            description: { type: Type.STRING, description: 'A compelling, one-sentence reason why the user should do this.' },
            category: { type: Type.STRING },
            link: { type: Type.STRING, description: 'A relevant URL if applicable, otherwise empty string.' },
        },
        required: ["title", "description", "category", "link"],
    }
};

const buildSocialContextPrompt = (userState: AppState, sharedContext: SharedContext): string => {
    let prompt = `Main user "${userState.userProfile.username}"'s data:\n- Hobbies: ${userState.hobbies.join(', ') || 'None'}\n- Inventory: ${userState.inventory.map(i => i.name).join(', ') || 'None'}`;

    if (sharedContext.partner) {
        prompt += `\n\nPartner "${sharedContext.partner.userProfile.username}"'s data:\n- Hobbies: ${sharedContext.partner.hobbies.join(', ') || 'None'}\n- Inventory: ${sharedContext.partner.inventory.map(i => i.name).join(', ') || 'None'}`;
    }
    if (sharedContext.friends.length > 0) {
        sharedContext.friends.forEach(friend => {
            prompt += `\n\nFriend "${friend.userProfile.username}"'s data:\n- Hobbies: ${friend.hobbies.join(', ') || 'None'}\n- Inventory: ${friend.inventory.map(i => i.name).join(', ') || 'None'}`;
        });
    }
    return prompt;
};

export const geminiService = {
    async getDailyRefresh() {
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: "Generate a single, interesting trivia question from general knowledge, geography, science, or history. Avoid riddles. The question should be engaging and informative. Provide a 'question' and a short 'answer'.",
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            question: { type: Type.STRING },
                            answer: { type: Type.STRING },
                        },
                        required: ["question", "answer"],
                    },
                    temperature: 0.8,
                }
            });
            const data = JSON.parse(response.text);
            return data;
        } catch (error) {
            console.error("Error fetching daily refresh:", error);
            return { question: "Could not load a question. Try again later!", answer: "" };
        }
    },

    async categorizeInventory(text: string) {
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Analyze the following text which lists a user's items, hobbies, or subscriptions. Categorize each distinct item into the most appropriate category. Here's the text: "${text}"`,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: inventorySchema,
                }
            });
            return JSON.parse(response.text);
        } catch (error) {
            console.error("Error categorizing inventory:", error);
            return [];
        }
    },
    
    async getInventorySuggestions(mood: Mood, socialContext: SocialContext, userState: AppState, sharedContext: SharedContext, timeAvailability: TimeAvailability | null, isDateNight: boolean): Promise<Suggestion[]> {
        const socialPrompt = buildSocialContextPrompt(userState, sharedContext);
        
        let dateNightPrompt = '';
        if (isDateNight && socialContext === SocialContext.MyPartner) {
            dateNightPrompt = `
                This is a DATE NIGHT. Suggestions must be romantic, special, and suitable for a couple.
                - Suggest ONE new, specific, commercially available item they could acquire to enhance the date (e.g., "a bottle of 2018 Château Montelena Chardonnay", "the board game 'Fog of Love'", "a high-quality dark chocolate for a tasting"). Include this in the description.
                - Title the suggestions with a romantic theme.
            `;
        }

        const prompt = `
            You are an expert decision-making assistant AI. Your ONLY goal is to provide HYPER-SPECIFIC, actionable activity suggestions. Vague or generic ideas are strictly forbidden.

            Based on the user data below, suggest 2-4 activities.
            - Current Mood: ${mood}
            - Social Context: ${socialContext}
            - Time Available: ${timeAvailability || 'Not specified'}
            
            USER DATA:
            ${socialPrompt}
            
            ${dateNightPrompt}

            **CRITICAL RULES FOR HYPER-SPECIFIC SUGGESTIONS:**
            - **NO VAGUE VERBS:** Never suggest "Cook," "Play," "Watch," "Listen," or "Do." ALWAYS specify the exact item.
            - **MUST BE SPECIFIC:**
                - BAD: "Cook something". GOOD: "Make the popular 'Marry Me Chicken' recipe using the chicken and cream you have."
                - BAD: "Play a board game". GOOD: "Set up and play a game of 'Catan' from your board games collection."
                - BAD: "Dance". GOOD: "Learn the basic Salsa step together by watching a tutorial for the song 'Vivir Mi Vida' by Marc Anthony."
                - BAD: "Watch a movie". GOOD: "Watch the movie 'Dune: Part Two' on your Max subscription."
            - **USE INVENTORY:** You MUST ground your suggestions in the user's (and their friends'/partner's) inventory and hobbies. Mention the specific items they own. For example: "Use your yoga mat to follow this 15-minute gentle yoga video..."
            - **MUTUAL SUGGESTIONS:** If multiple people are involved, the suggestion MUST be based on their SHARED or complementary interests. Justify why it's a good fit for the group. Example: "Since you both enjoy strategy games, play 'Wingspan' from Jane's collection."
            - **OUTPUT FORMAT:** The title must be the specific action (e.g., "Make Marry Me Chicken"). The description must be a single, compelling sentence. The category should be from the user's hobbies or inventory categories.
        `;
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: suggestionsSchema,
                }
            });
            const data = JSON.parse(response.text);
            return data.map((d: any) => ({ ...d, icon: isDateNight ? 'DateNight' : 'Inventory' }));
        } catch (error) {
            console.error("Error getting inventory suggestions:", error);
            return [];
        }
    },

    async getExternalContentSuggestions(mood: Mood, socialContext: SocialContext, userState: AppState, sharedContext: SharedContext, timeAvailability: TimeAvailability | null, isDateNight: boolean): Promise<Suggestion[]> {
         const socialPrompt = buildSocialContextPrompt(userState, sharedContext);
         const dateNightPrompt = isDateNight ? "The user is on a date night with their partner, so suggest a romantic movie or TV series they can watch together based on their shared interests." : "";
         
         const prompt = `
            You are a media recommendation expert. Your suggestions MUST be for specific, existing items. Generic recommendations are forbidden.

            Suggest exactly one podcast, one book, and one YouTube video for a user feeling ${mood} in a '${socialContext}' context with '${timeAvailability}' available.
            The user's Spotify account status is: ${userState.userProfile.isSpotifyLinked ? 'Connected' : 'Not Connected'}.

            USER DATA:
            ${socialPrompt}
            
            **CRITICAL RULES FOR HYPER-SPECIFIC SUGGESTIONS:**
            - **MUST BE SPECIFIC:**
                - BAD: "a fantasy book". GOOD: "the book 'The Midnight Library' by Matt Haig."
                - BAD: "a tech review channel". GOOD: "the latest MKBHD video titled 'iPhone 15 Pro Review: The Final Form!'."
                - BAD: "a true crime podcast". GOOD: "the episode 'The Disappearance of Tara Calico' from the 'Crime Junkie' podcast."
            - **SHARED TASTES:** If multiple people are involved, the content MUST align with their SHARED tastes. Justify the choice. Example: "Since you both like sci-fi, read 'Project Hail Mary' by Andy Weir."
            - **DATE NIGHT:** ${dateNightPrompt}
            - **LINKS:** If the user's Spotify is Connected, you MUST provide a direct Spotify URL for any podcast suggestions. For other content, provide a google.com search link for the exact title.
            - **OUTPUT FORMAT:** Provide a title, a short compelling description, and the category ('Podcast', 'Book', or 'YouTube Video').
        `;
         try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: suggestionsSchema,
                }
            });
            const suggestions = JSON.parse(response.text);
            const typedSuggestions: Suggestion[] = suggestions.map((s: any) => {
                let icon: Suggestion['icon'] = 'Book';
                if (s.category === 'Podcast' && s.link.includes('spotify')) icon = 'Spotify';
                else if (s.category === 'Podcast') icon = 'Podcast';
                if (s.category === 'YouTube Video') icon = 'YouTube';
                return { ...s, icon: isDateNight ? 'DateNight' : icon };
            });
            return typedSuggestions.slice(0, 3);
        } catch (error) {
            console.error("Error getting external content suggestions:", error);
            return [];
        }
    },
    
    async getLocalActivitySuggestions(mood: Mood, socialContext: SocialContext, userLocation: { latitude: number; longitude: number }, userState: AppState, sharedContext: SharedContext, timeAvailability: TimeAvailability | null, isDateNight: boolean): Promise<Suggestion[]> {
        const socialPrompt = buildSocialContextPrompt(userState, sharedContext);
        const dateNightPrompt = isDateNight ? "This is a DATE NIGHT. Suggestions should be romantic and suitable for a couple (e.g., 'a scenic viewpoint for sunset', 'a cozy restaurant with great ambiance', 'a couples' cooking class')." : "";
        
        const prompt = `
            Find 2-3 specific local places or activities suitable for someone feeling ${mood} in a '${socialContext}' context with '${timeAvailability}' available.
            
            USER DATA:
            ${socialPrompt}

            - If multiple people are involved, find a local spot that caters to their SHARED interests.
            - ${dateNightPrompt}
            - For example, if they are 'Tired', suggest a quiet park like 'Green Lake Park' or a cozy cafe like 'Cafe Allegro'. If 'Energized', suggest 'a 3-mile hike at Discovery Park'.
            - If you provide a text response, format it as a markdown list. Each list item MUST start with "- **Name of Place:**" followed by a short description.
        `;
         try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    tools: [{ googleMaps: {} }],
                    toolConfig: {
                        retrievalConfig: {
                            latLng: {
                                latitude: userLocation.latitude,
                                longitude: userLocation.longitude,
                            }
                        }
                    }
                }
            });

            const text = response.text;
            const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
            
            const suggestions: Suggestion[] = [];
            if (groundingChunks && groundingChunks.length > 0) {
                for (const chunk of groundingChunks) {
                    if (chunk.maps) {
                        suggestions.push({
                            title: chunk.maps.title,
                            description: `A great local spot for a ${mood} day.`,
                            category: chunk.maps.placeSubtypes?.[0] || 'Local Activity',
                            link: chunk.maps.uri,
                            icon: isDateNight ? 'DateNight' : 'Local'
                        });
                    }
                }
            }
            
            if (suggestions.length === 0 && text) {
                const lines = text.split('\n');
                const regex = /-\s*\*\*(.*?):\*\*\s*(.*)/;
                for (const line of lines) {
                    const match = line.match(regex);
                    if (match) {
                        suggestions.push({
                            title: match[1].trim(),
                            description: match[2].trim(),
                            category: "Local Activity",
                            icon: isDateNight ? 'DateNight' : 'Local'
                        });
                    }
                }
            }

            return suggestions.slice(0, 3);
        } catch (error) {
            console.error("Error getting local activity suggestions:", error);
            return [];
        }
    },

    async getChatMessage(history: ChatMessage[], mood: Mood | null, inventory: InventoryItem[], hobbies: string[]) {
        const chatHistory = history.map(m => `${m.sender}: ${m.text}`).join('\n');
        const inventoryList = inventory.map(i => i.name).join(', ');
        const hobbyList = hobbies.join(', ');

        const prompt = `
            You are a supportive and insightful life companion AI. Your goal is to help the user make a decision on an activity by being an expert assistant.

            Current Context:
            - User's Mood: ${mood || 'Not specified'}.
            - User's Inventory/Subscriptions: ${inventoryList}.
            - User's Hobbies: ${hobbyList}.

            Conversation History:
            ${chatHistory}
            
            AI: Your task is to follow these rules strictly:
            1.  **Be Inquisitive First:** If the user is vague (e.g., "what should I do?"), your first response MUST be a single, simple clarifying question to get more context. Do not suggest anything yet. Good questions are: "How much time do you have?", "Are you thinking of staying in or going out?", "What's your energy level for this?".
            2.  **Give ONE Hyper-Specific Suggestion:** Once you have enough context (like time and location preference), give ONLY ONE direct, hyper-specific suggestion.
                - BAD: "You could watch a movie." GOOD: "Based on your love for sci-fi, you should watch 'Blade Runner 2049' on your Netflix subscription."
                - BAD: "Maybe play a game." GOOD: "How about a 30-minute round of 'Splendor' from your board game collection?"
            3.  **Provide Follow-Ups:** Your response should always include 2-3 short, clickable follow-up suggestions for the user. These could be alternative ideas or questions to refine the suggestion.
            4.  **JSON Format:** Your entire response MUST be in JSON format with "responseText" and "suggestions" keys.
        `;

        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-pro',
                contents: prompt,
                config: {
                     responseMimeType: "application/json",
                     responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            responseText: { type: Type.STRING },
                            suggestions: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING },
                            }
                        },
                        required: ["responseText", "suggestions"]
                     }
                }
            });
            return JSON.parse(response.text);
        } catch (error) {
            console.error("Error getting chat message:", error);
            return { responseText: "I'm having a little trouble connecting right now. Please try again in a moment.", suggestions: [] };
        }
    },

    async getWeeklySurveyQuestions(existingHobbies: string[]): Promise<SurveyQuestion[]> {
        const prompt = `
            Generate 3 engaging, multiple-choice questions to get to know a user better for a wellness app.
            Each question should have 4 distinct and interesting options.
            The questions should help reveal user preferences in areas like movies, music, activities, or food.
            For example: "Which of these movies sounds most appealing right now?". Options: "A mind-bending sci-fi thriller", "A heartwarming animated adventure", "A classic black-and-white drama", "A hilarious slapstick comedy".
            Do not ask about hobbies the user has already told us about.
            Existing Hobbies: ${existingHobbies.join(', ')}
            Return a JSON object with a 'questions' key which is an array of 3 objects, each with a 'question' (string) and 'options' (array of 4 strings).
        `;
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            questions: {
                                type: Type.ARRAY,
                                items: {
                                    type: Type.OBJECT,
                                    properties: {
                                        question: { type: Type.STRING },
                                        options: { type: Type.ARRAY, items: { type: Type.STRING } }
                                    },
                                    required: ["question", "options"]
                                }
                            },
                        },
                        required: ["questions"],
                    },
                },
            });
            const data = JSON.parse(response.text);
            return data.questions;
        } catch (error) {
            console.error("Error fetching survey questions:", error);
            return [
                { question: "Which movie would you prefer to watch tonight?", options: ["Predator", "The Prestige", "This Is The End", "Cars"] },
                { question: "What kind of activity sounds best?", options: ["A competitive board game", "A long hike in nature", "Trying a new recipe", "Visiting a museum"] },
                { question: "Which music genre are you in the mood for?", options: ["80s Pop", "Acoustic Folk", "Classic Rock", "Instrumental Jazz"] },
            ];
        }
    },

    async processSurveyAnswers(answers: Record<string, string>, hobbies: string[], inventory: InventoryItem[]) {
        const inventoryList = inventory.map(i => i.name).join(', ');
        const hobbyList = hobbies.join(', ');
        const surveyAnswers = JSON.stringify(answers);

        const prompt = `
            Analyze the following user survey answers. The answer is a user's choice from a multiple-choice question.
            Based on the user's choice, infer potential new hobbies or inventory items.
            For example, if the user chose 'A long hike in nature', a good new hobby would be 'Hiking'.
            If they chose 'The Prestige', a good inventory item would be 'Interest in Christopher Nolan films'.
            Only identify items not already present in their existing hobbies and inventory lists.
            Existing Hobbies: ${hobbyList}.
            Existing Inventory: ${inventoryList}.
            Survey Answers: ${surveyAnswers}.
            Return a JSON object with two keys: 'newHobbies' (an array of strings) and 'newInventoryItems' (an array of objects matching the inventory schema).
            If nothing new is found, return empty arrays.
        `;
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-pro',
                contents: prompt,
                config: {
                    thinkingConfig: { thinkingBudget: 32768 },
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            newHobbies: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING }
                            },
                            newInventoryItems: inventorySchema,
                        },
                        required: ["newHobbies", "newInventoryItems"],
                    },
                },
            });
            return JSON.parse(response.text);
        } catch (error) {
            console.error("Error processing survey answers:", error);
            return { newHobbies: [], newInventoryItems: [] };
        }
    },

    async processHobbyDetails(hobby: string, details: string) {
        const prompt = `
            A user has the hobby "${hobby}". They provided these additional details: "${details}".
            Analyze the details and extract specific items. For example, if the hobby is "Reading" and details are "I love The Lord of the Rings and Harry Potter", the items should be "The Lord of the Rings series" and "Harry Potter series".
            If the hobby is "Cooking" and details are "I make great pasta carbonara", the item should be "Pasta Carbonara".
            Return a JSON object with a single key 'newInventoryItems' which is an array of objects matching the inventory schema.
            If no specific items can be extracted, return an empty array.
        `;
        try {
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.OBJECT,
                        properties: {
                            newInventoryItems: inventorySchema,
                        },
                        required: ["newInventoryItems"],
                    },
                },
            });
            return JSON.parse(response.text);
        } catch (error) {
            console.error("Error processing hobby details:", error);
            return { newInventoryItems: [] };
        }
    },

    startLiveSession(callbacks: {
        onOpen: () => void,
        onMessage: (message: LiveServerMessage) => Promise<void>,
        onError: (e: ErrorEvent) => void,
        onClose: (e: CloseEvent) => void,
    }): Promise<LiveSession> {
        return ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: callbacks.onOpen,
                onmessage: callbacks.onMessage,
                onerror: callbacks.onError,
                onclose: callbacks.onClose,
            },
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
                },
                inputAudioTranscription: {},
                outputAudioTranscription: {},
                systemInstruction: 'You are a friendly and helpful life companion. Keep your responses concise and conversational.',
            },
        });
    }
};