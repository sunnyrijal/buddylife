import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AppState, Habit, Mood, SocialContext, InventoryItem, ChatMessage, OnboardingData, HabitDifficulty, WeeklySurvey, TimeAvailability, LifeCompanionData, RelationshipStatus, ProactiveSuggestionType } from '@/types';
import { storageService } from '@/services/storageService';
import { geminiService } from '@/services/geminiService';
import { INITIAL_APP_STATE, XP_REWARDS, XP_PER_LEVEL, ACHIEVEMENTS } from '@/constants';
import { LiveServerMessage, Blob as GenaiBlob } from '@google/genai';

// --- Audio Utilities ---
function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): GenaiBlob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

const GENERIC_HOBBIES = ["reading", "cooking", "gaming", "movies", "music", "exercise"];

export const useAppStore = () => {
    const [data, setData] = useState<LifeCompanionData>(storageService.loadData());
    const [state, setState] = useState<AppState>(() => {
        const initialData = storageService.loadData();
        const currentUser = initialData.currentUser;
        if (currentUser && initialData.users[currentUser]) {
            return initialData.users[currentUser];
        }
        return INITIAL_APP_STATE;
    });

    const audioRef = useRef<{
        inputAudioContext: AudioContext | null,
        outputAudioContext: AudioContext | null,
        micStream: MediaStream | null,
        scriptProcessor: ScriptProcessorNode | null,
        sources: Set<AudioBufferSourceNode>,
        nextStartTime: number,
    }>({
        inputAudioContext: null,
        outputAudioContext: null,
        micStream: null,
        scriptProcessor: null,
        sources: new Set(),
        nextStartTime: 0,
    }).current;
    
    useEffect(() => {
        storageService.saveData(data);
    }, [data]);

    useEffect(() => {
        const currentUser = data.currentUser;
        if(currentUser && data.users[currentUser]){
            setState(data.users[currentUser]);
        } else {
            setState(INITIAL_APP_STATE);
        }
    }, [data]);
    
    const updateCurrentUserState = (updater: (prevState: AppState) => AppState) => {
        setData(prevData => {
            const currentUser = prevData.currentUser;
            if (!currentUser) return prevData;

            const oldState = prevData.users[currentUser] || INITIAL_APP_STATE;
            const newState = updater(oldState);
            
            return {
                ...prevData,
                users: {
                    ...prevData.users,
                    [currentUser]: newState,
                }
            };
        });
    };

    const setLoading = (isLoading: boolean) => updateCurrentUserState(prev => ({ ...prev, isLoading }));
    const setError = (error: string | null) => updateCurrentUserState(prev => ({ ...prev, error }));

    // --- User & Auth ---
    const login = (username: string) => {
        setData(prevData => {
            const userExists = !!prevData.users[username];
            const newUsers = { ...prevData.users };
            if (!userExists) {
                 newUsers[username] = {
                    ...INITIAL_APP_STATE,
                    userProfile: {
                        ...INITIAL_APP_STATE.userProfile,
                        username: username,
                        isLoggedIn: true,
                    }
                };
            } else {
                newUsers[username] = {
                    ...newUsers[username],
                    userProfile: {
                        ...newUsers[username].userProfile,
                        isLoggedIn: true,
                    }
                }
            }
            return {
                currentUser: username,
                users: newUsers,
            }
        });
    };

    const logout = () => {
        setData(prevData => ({ ...prevData, currentUser: null }));
        setState(INITIAL_APP_STATE);
    };
    
    const resetData = () => {
        setData(prevData => {
            const currentUser = prevData.currentUser;
            if (!currentUser) return prevData;
            const newUsers = { ...prevData.users };
            newUsers[currentUser] = {
                ...INITIAL_APP_STATE,
                    userProfile: {
                    ...INITIAL_APP_STATE.userProfile,
                    username: currentUser,
                    isLoggedIn: true,
                    }
            };
            return {
                ...prevData,
                users: newUsers,
            }
        });
    }

    const setOnboardingCompleted = () => {
        updateCurrentUserState(prev => ({ ...prev, userProfile: { ...prev.userProfile, onboardingCompleted: true } }));
    };

    const upgradeSubscription = (tier: 'Premium') => {
        updateCurrentUserState(prev => ({
            ...prev,
            userProfile: {
                ...prev.userProfile,
                subscriptionTier: tier,
                trialEndDate: null,
            }
        }));
    };
    
    const setActiveScreen = (screen: 'Today' | 'Journey' | 'Profile' | 'Chat') => {
         updateCurrentUserState(prev => ({ ...prev, activeScreen: screen }));
    }

    const addXP = useCallback((amount: number) => {
        updateCurrentUserState(prev => {
            const newXP = prev.userProfile.xp + amount;
            let newLevel = prev.userProfile.level;
            let newStreakFreezes = prev.userProfile.streakFreezes;
            let xpForNextLevel = newXP;

            if (xpForNextLevel >= XP_PER_LEVEL) {
                newLevel += 1;
                xpForNextLevel -= XP_PER_LEVEL;
                newStreakFreezes += 1;
            }

            return {
                ...prev,
                userProfile: {
                    ...prev.userProfile,
                    xp: xpForNextLevel,
                    level: newLevel,
                    streakFreezes: newStreakFreezes
                }
            };
        });
    }, []);

    const checkAndGrantAchievement = useCallback((type: 'HABIT_STARTER' | 'WEEK_WARRIOR' | 'LEVEL_UP' | 'COLLECTOR' | 'CONVERSATIONALIST', value?: number) => {
        updateCurrentUserState(prev => {
            if (prev.userProfile.achievements.includes(type)) return prev;

            let achievementGet = false;
            if (type === 'HABIT_STARTER' && prev.habits.some(h => h.completions.length > 0)) {
                achievementGet = true;
            } else if (type === 'WEEK_WARRIOR' && prev.habits.some(h => h.currentStreak >= 7)) {
                achievementGet = true;
            } else if (type === 'LEVEL_UP' && value && value >= 5 && !prev.userProfile.achievements.includes('LEVEL_UP')) {
                achievementGet = true;
            } else if (type === 'COLLECTOR' && prev.inventory.length >= 10) {
                achievementGet = true;
            } else if (type === 'CONVERSATIONALIST' && prev.chatHistory.filter(c => c.sender === 'user').length >= 10) {
                 achievementGet = true;
            }
            
            const achievement = ACHIEVEMENTS.find(a => a.id === type);
            if (achievementGet && achievement) {
                const newProfile = {
                    ...prev.userProfile,
                    achievements: [...prev.userProfile.achievements, type],
                    xp: prev.userProfile.xp + achievement.xp,
                    gold: prev.userProfile.gold + achievement.gold
                };
                return { ...prev, userProfile: newProfile };
            }
            return prev;
        });
    }, []);

    const setMood = (mood: Mood | null) => {
        updateCurrentUserState(prev => ({ ...prev, currentMood: mood, inventorySuggestions: [], externalContentSuggestions: [], localActivitySuggestions: [] }));
    };

    const setSocialContext = (context: SocialContext) => {
        updateCurrentUserState(prev => ({ ...prev, socialContext: context, inventorySuggestions: [], externalContentSuggestions: [], localActivitySuggestions: [] }));
    };

    const setTimeAvailability = (time: TimeAvailability | null) => {
        updateCurrentUserState(prev => ({ ...prev, currentTimeAvailability: time, inventorySuggestions: [], externalContentSuggestions: [], localActivitySuggestions: [] }));
    };

    const toggleDateNightMode = () => {
        updateCurrentUserState(prev => ({ ...prev, isDateNightMode: !prev.isDateNightMode, inventorySuggestions: [], externalContentSuggestions: [], localActivitySuggestions: [] }));
    };

    const fetchSuggestions = useCallback(() => {
        if (!state.currentMood || !state.socialContext || !state.currentTimeAvailability) return;
        setLoading(true);
        setError(null);

        const fetchAll = async () => {
            try {
                const allUsers = data.users;
                const sharedContext = {
                    partner: state.userProfile.partnerUsername ? allUsers[state.userProfile.partnerUsername] || null : null,
                    friends: state.userProfile.friendUsernames.map(f => allUsers[f]).filter(Boolean) as AppState[],
                };

                const invPromise = geminiService.getInventorySuggestions(state.currentMood!, state.socialContext!, state, sharedContext, state.currentTimeAvailability, state.isDateNightMode);
                const extPromise = geminiService.getExternalContentSuggestions(state.currentMood!, state.socialContext!, state, sharedContext, state.currentTimeAvailability, state.isDateNightMode);
                const locPromise = new Promise<any>((resolve) => {
                    navigator.geolocation.getCurrentPosition(
                        (position) => {
                            const { latitude, longitude } = position.coords;
                            resolve(geminiService.getLocalActivitySuggestions(state.currentMood!, state.socialContext!, { latitude, longitude }, state, sharedContext, state.currentTimeAvailability, state.isDateNightMode));
                        },
                        () => resolve([]));
                });

                const [inv, ext, loc] = await Promise.all([invPromise, extPromise, locPromise]);

                updateCurrentUserState(prev => ({
                    ...prev,
                    inventorySuggestions: inv,
                    externalContentSuggestions: ext,
                    localActivitySuggestions: loc,
                    isLoading: false
                }));
            } catch (e) {
                setError("Failed to fetch suggestions.");
                setLoading(false);
            }
        };

        fetchAll();
    }, [state.currentMood, state.socialContext, state.currentTimeAvailability, state.isDateNightMode, state.userProfile.partnerUsername, state.userProfile.friendUsernames, data.users]);

    const fetchDailyRefresh = useCallback(() => {
        if (state.dailyRefresh) return;
        setLoading(true);
        geminiService.getDailyRefresh().then(data => {
            const newRefresh = {
                id: `dr-${new Date().toISOString()}`,
                type: ProactiveSuggestionType.DailyRefresh,
                title: "Daily Refresh",
                question: data.question,
                answer: data.answer,
                icon: 'Lightbulb'
            };
            updateCurrentUserState(prev => ({...prev, dailyRefresh: newRefresh, isLoading: false}));
        });
    }, [state.dailyRefresh]);
    
    const completeNudge = () => addXP(XP_REWARDS.NUDGE);
    const completeDailyRefresh = () => addXP(XP_REWARDS.DAILY_REFRESH);

    const addHabit = (habit: Omit<Habit, 'id' | 'currentStreak' | 'longestStreak' | 'completions' | 'lastCompletionDate'>) => {
        const newHabit: Habit = { ...habit, id: Date.now().toString(), currentStreak: 0, longestStreak: 0, completions: [], lastCompletionDate: null };
        updateCurrentUserState(prev => ({ ...prev, habits: [...prev.habits, newHabit] }));
    };
    
    const updateHabit = (updatedHabit: Habit) => {
        updateCurrentUserState(prev => ({ ...prev, habits: prev.habits.map(h => h.id === updatedHabit.id ? updatedHabit : h) }));
    };

    const deleteHabit = (habitId: string) => {
        updateCurrentUserState(prev => ({ ...prev, habits: prev.habits.filter(h => h.id !== habitId) }));
    };

    const completeHabit = (habitId: string) => {
        updateCurrentUserState(prev => {
            const today = new Date().toISOString().split('T')[0];
            const habit = prev.habits.find(h => h.id === habitId);
            if (!habit || habit.completions.some(c => c.date === today)) return prev;

            const yesterday = new Date();
            yesterday.setDate(yesterday.getDate() - 1);
            const yesterdayStr = yesterday.toISOString().split('T')[0];
            let newStreak = habit.lastCompletionDate === yesterdayStr ? habit.currentStreak + 1 : 1;
            
            const updatedHabit = { ...habit, currentStreak: newStreak, longestStreak: Math.max(habit.longestStreak, newStreak), lastCompletionDate: today, completions: [...habit.completions, { date: today }] };
            const newHabits = prev.habits.map(h => h.id === habitId ? updatedHabit : h);

            let xpGained = 0;
            if (habit.difficulty === HabitDifficulty.Easy) xpGained = XP_REWARDS.HABIT_EASY;
            if (habit.difficulty === HabitDifficulty.Medium) xpGained = XP_REWARDS.HABIT_MEDIUM;
            if (habit.difficulty === HabitDifficulty.Hard) xpGained = XP_REWARDS.HABIT_HARD;
            
            const newXP = prev.userProfile.xp + xpGained;
            return { ...prev, habits: newHabits, userProfile: { ...prev.userProfile, xp: newXP }};
        });
    };
    
    const addInventoryFromOnboarding = async (onboardingData: OnboardingData) => {
        setLoading(true);
        const { streaming, games, socialMedia, hobbies, inventoryText, gameListText } = onboardingData;
        const combinedText = `Streaming: ${streaming.join(', ')}. Games: ${games.join(', ')}. Specific Games: ${gameListText || 'N/A'}. Social Media: ${socialMedia.join(', ')}. Other: ${inventoryText}.`;
        const categorizedItems = await geminiService.categorizeInventory(combinedText);
        
        updateCurrentUserState(prev => {
            const newItems: InventoryItem[] = categorizedItems.map((item: any) => ({ id: `${Date.now()}-${item.name}`, ...item }));
            return { ...prev, hobbies: [...prev.hobbies, ...hobbies], inventory: [...prev.inventory, ...newItems], isLoading: false, userProfile: { ...prev.userProfile, onboardingCompleted: true } }
        });
    };
    
    const processBulkInventory = async (text: string) => {
        setLoading(true);
        const categorizedItems = await geminiService.categorizeInventory(text);
        updateCurrentUserState(prev => {
            const newItems: InventoryItem[] = categorizedItems.map((item: any) => ({ id: `${Date.now()}-${item.name}`, ...item }));
            return { ...prev, inventory: [...prev.inventory, ...newItems], isLoading: false };
        });
    };

    const updateInventoryItem = (item: InventoryItem) => {
        updateCurrentUserState(prev => ({ ...prev, inventory: prev.inventory.map(i => i.id === item.id ? item : i) }));
    };

    const deleteInventoryItem = (itemId: string) => {
        updateCurrentUserState(prev => ({ ...prev, inventory: prev.inventory.filter(i => i.id !== itemId) }));
    };

    const setHobbyToDetail = (hobby: string | null) => {
        updateCurrentUserState(prev => ({...prev, hobbyToDetail: hobby}));
    };

    const addHobby = (hobby: string) => {
        const trimmedHobby = hobby.trim();
        if (GENERIC_HOBBIES.includes(trimmedHobby.toLowerCase())) {
            setHobbyToDetail(trimmedHobby);
        } else {
            updateCurrentUserState(prev => {
                if (!prev.hobbies.find(h => h.toLowerCase() === trimmedHobby.toLowerCase())) {
                    return { ...prev, hobbies: [...prev.hobbies, trimmedHobby] };
                }
                return prev;
            });
        }
    };
    
    const addHobbyWithDetails = async (hobby: string, details: string) => {
        setLoading(true);
        const result = await geminiService.processHobbyDetails(hobby, details);
        updateCurrentUserState(prev => {
            const newItems: InventoryItem[] = result.newInventoryItems.map((item: any) => ({
                id: `${Date.now()}-${item.name}`,
                ...item
            }));
            const hobbyExists = prev.hobbies.find(h => h.toLowerCase() === hobby.toLowerCase());
            return {
                ...prev,
                hobbies: hobbyExists ? prev.hobbies : [...prev.hobbies, hobby],
                inventory: [...prev.inventory, ...newItems],
                isLoading: false,
                hobbyToDetail: null,
            };
        });
    };
    
    const deleteHobby = (hobby: string) => {
        updateCurrentUserState(prev => ({ ...prev, hobbies: prev.hobbies.filter(h => h.trim().toLowerCase() !== hobby.trim().toLowerCase()) }));
    };

    const addChatMessage = async (text: string) => {
        const userMessage: ChatMessage = { id: Date.now().toString(), sender: 'user', text, timestamp: new Date().toISOString() };
        updateCurrentUserState(prev => ({ ...prev, chatHistory: [...prev.chatHistory, userMessage], isLoading: true }));
        const aiResponseData = await geminiService.getChatMessage([...state.chatHistory, userMessage], state.currentMood, state.inventory, state.hobbies);
        const aiMessage: ChatMessage = { id: (Date.now() + 1).toString(), sender: 'ai', text: aiResponseData.responseText, suggestions: aiResponseData.suggestions, timestamp: new Date().toISOString() };
        updateCurrentUserState(prev => ({ ...prev, chatHistory: [...prev.chatHistory, aiMessage], isLoading: false }));
    };

    const endVoiceChat = useCallback(() => {
        state.voiceSession?.then((session: any) => session.close());
        audioRef.micStream?.getTracks().forEach(track => track.stop());
        if (audioRef.inputAudioContext?.state !== 'closed') audioRef.inputAudioContext?.close();
        if (audioRef.outputAudioContext?.state !== 'closed') audioRef.outputAudioContext?.close();
        audioRef.scriptProcessor?.disconnect();
        updateCurrentUserState(prev => ({ ...prev, isVoiceSessionActive: false, voiceSession: null, currentTranscription: { input: '', output: '' } }));
    }, [state.voiceSession, audioRef]);

    const startVoiceChat = useCallback(async () => {
        if (state.isVoiceSessionActive) return;
        try {
            audioRef.inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            audioRef.outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            audioRef.micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            const sessionPromise = geminiService.startLiveSession({ onOpen: () => {}, onMessage: async () => {}, onError: () => {}, onClose: () => {} });
            updateCurrentUserState(prev => ({ ...prev, isVoiceSessionActive: true, voiceSession: sessionPromise }));
        } catch (err) {
            setError("Could not access microphone.");
        }
    }, [state.isVoiceSessionActive, audioRef]);

    const fetchWeeklySurvey = useCallback(async () => {
        setLoading(true);
        const questions = await geminiService.getWeeklySurveyQuestions(state.hobbies);
        const newSurvey: WeeklySurvey = { id: `survey-${Date.now()}`, questions, answers: {} };
        updateCurrentUserState(prev => ({ ...prev, currentWeeklySurvey: newSurvey, isLoading: false }));
    }, [state.hobbies]);

    const submitWeeklySurvey = useCallback(async (answers: Record<string, string>) => {
        setLoading(true);
        const result = await geminiService.processSurveyAnswers(answers, state.hobbies, state.inventory);
        
        updateCurrentUserState(prev => {
             const uniqueNewHobbies = result.newHobbies.filter((h: string) => !prev.hobbies.includes(h));
            const uniqueNewItems: InventoryItem[] = result.newInventoryItems.map((item: any) => ({ id: `${Date.now()}-${item.name}`, ...item }));
             let newChatMessage: ChatMessage | null = null;
            if (uniqueNewHobbies.length > 0 || uniqueNewItems.length > 0) {
                const text = `Thanks for sharing! I've updated your profile with new hobbies and items to give you better suggestions.`.trim();
                newChatMessage = { id: `survey-summary-${Date.now()}`, sender: 'ai', text, timestamp: new Date().toISOString() };
            }
            return {
                ...prev,
                hobbies: [...prev.hobbies, ...uniqueNewHobbies],
                inventory: [...prev.inventory, ...uniqueNewItems],
                chatHistory: newChatMessage ? [...prev.chatHistory, newChatMessage] : prev.chatHistory,
                userProfile: { ...prev.userProfile, lastSurveyDate: new Date().toISOString() },
                isSurveyDue: false,
                currentWeeklySurvey: null,
                isLoading: false,
            };
        });
    }, [state.hobbies, state.inventory]);

    const updateRelationshipStatus = (status: RelationshipStatus) => {
        updateCurrentUserState(prev => ({ ...prev, userProfile: { ...prev.userProfile, relationshipStatus: status, partnerUsername: status === RelationshipStatus.Single ? null : prev.userProfile.partnerUsername } }));
    };

    const connectSpotify = () => {
        updateCurrentUserState(prev => ({...prev, userProfile: {...prev.userProfile, isSpotifyLinked: true}}));
    };

    const disconnectSpotify = () => {
        updateCurrentUserState(prev => ({...prev, userProfile: {...prev.userProfile, isSpotifyLinked: false}}));
    };

    const syncWithPartner = (partnerUsername: string): boolean => {
        if (!data.users[partnerUsername] || partnerUsername === state.userProfile.username) {
            setError("User not found or you cannot add yourself.");
            return false;
        }
        setData(prevData => {
            const currentUser = prevData.currentUser!;
            const newUsers = { ...prevData.users };
            newUsers[currentUser] = { ...newUsers[currentUser], userProfile: { ...newUsers[currentUser].userProfile, partnerUsername, relationshipStatus: RelationshipStatus.InARelationship, } };
            newUsers[partnerUsername] = { ...newUsers[partnerUsername], userProfile: { ...newUsers[partnerUsername].userProfile, partnerUsername: currentUser, relationshipStatus: RelationshipStatus.InARelationship, } };
            return { ...prevData, users: newUsers };
        });
        return true;
    };

    const addFriend = (friendUsername: string): boolean => {
         if (!data.users[friendUsername] || friendUsername === state.userProfile.username) {
            setError("User not found or you cannot add yourself.");
            return false;
        }
         updateCurrentUserState(prev => {
            if(prev.userProfile.friendUsernames.includes(friendUsername)) return prev;
            return { ...prev, userProfile: { ...prev.userProfile, friendUsernames: [...prev.userProfile.friendUsernames, friendUsername] } }
         });
         return true;
    };
    
    const removeFriend = (friendUsername: string) => {
        updateCurrentUserState(prev => ({ ...prev, userProfile: { ...prev.userProfile, friendUsernames: prev.userProfile.friendUsernames.filter(f => f !== friendUsername) } }))
    };
    
     const removePartner = () => {
        const partnerUsername = state.userProfile.partnerUsername;
        if (!partnerUsername) return;
        setData(prevData => {
            const currentUser = prevData.currentUser!;
            const newUsers = { ...prevData.users };
            newUsers[currentUser] = { ...newUsers[currentUser], userProfile: { ...newUsers[currentUser].userProfile, partnerUsername: null, relationshipStatus: RelationshipStatus.Single }};
            if (newUsers[partnerUsername]) {
                 newUsers[partnerUsername] = { ...newUsers[partnerUsername], userProfile: { ...newUsers[partnerUsername].userProfile, partnerUsername: null, relationshipStatus: RelationshipStatus.Single }};
            }
            return { ...prevData, users: newUsers };
        });
    };
    
    const exportData = () => {
        const dataStr = JSON.stringify(state, null, 2);
        const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
        const linkElement = document.createElement('a');
        linkElement.setAttribute('href', dataUri);
        linkElement.setAttribute('download', 'life_companion_data.json');
        linkElement.click();
    };

    return {
        state,
        actions: {
            login, logout, resetData, setOnboardingCompleted, upgradeSubscription, setActiveScreen,
            addXP, setMood, setSocialContext, setTimeAvailability, toggleDateNightMode, fetchSuggestions,
            fetchDailyRefresh, completeNudge, completeDailyRefresh,
            addHabit, updateHabit, deleteHabit, completeHabit,
            addInventoryFromOnboarding, processBulkInventory, updateInventoryItem, deleteInventoryItem,
            addHobby, deleteHobby, addHobbyWithDetails, setHobbyToDetail,
            addChatMessage, startVoiceChat, endVoiceChat,
            fetchWeeklySurvey, submitWeeklySurvey,
            updateRelationshipStatus,
            connectSpotify, disconnectSpotify, syncWithPartner, addFriend, removeFriend, removePartner,
            exportData,
        }
    };
};