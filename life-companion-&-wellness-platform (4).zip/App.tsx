import React, { useEffect } from 'react';
import { useAppStore } from './hooks/useAppStore';
import { LoginScreen } from './screens/LoginScreen';
import { OnboardingScreen } from './screens/OnboardingScreen';
import { TodayScreen } from './screens/TodayScreen';
import { JourneyScreen } from './screens/JourneyScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { ChatScreen } from './screens/ChatScreen';
import { HomeIcon, FlameIcon, UserIcon, MessageSquareIcon } from './components/icons/Icons';
import { HobbyDetailModal } from './components/HobbyDetailModal';

function App() {
  const { state, actions } = useAppStore();
  const { userProfile, activeScreen, hobbyToDetail } = state;

  // Effect to end voice session if navigating away from chat screen
  useEffect(() => {
    if (activeScreen !== 'Chat' && state.isVoiceSessionActive) {
        actions.endVoiceChat();
    }
  }, [activeScreen, state.isVoiceSessionActive, actions]);


  if (!userProfile.isLoggedIn) {
    return <LoginScreen onLogin={actions.login} />;
  }

  if (!userProfile.onboardingCompleted) {
    return <OnboardingScreen username={userProfile.username!} onComplete={actions.addInventoryFromOnboarding} isLoading={state.isLoading} />;
  }

  const renderScreen = () => {
    switch (activeScreen) {
      case 'Today': return <TodayScreen state={state} actions={actions} />;
      case 'Journey': return <JourneyScreen state={state} actions={actions} />;
      case 'Chat': return <ChatScreen state={state} actions={actions} />;
      case 'Profile': return <ProfileScreen state={state} actions={actions} />;
      default: return <TodayScreen state={state} actions={actions} />;
    }
  };

  const isChatScreen = activeScreen === 'Chat';

  return (
    <div className="bg-gray-900 min-h-screen font-sans text-gray-100">
      <main className={`max-w-lg mx-auto ${isChatScreen ? '' : 'p-4 sm:p-6'}`}>
        {renderScreen()}
      </main>

      {hobbyToDetail && (
        <HobbyDetailModal
            isOpen={!!hobbyToDetail}
            onClose={() => actions.setHobbyToDetail(null)}
            onConfirm={actions.addHobbyWithDetails}
            hobby={hobbyToDetail}
            isLoading={state.isLoading}
        />
      )}

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 max-w-lg mx-auto bg-gray-800 border-t border-gray-700">
        <div className="flex justify-around h-20">
          <NavButton
            label="Today"
            icon={<HomeIcon />}
            isActive={activeScreen === 'Today'}
            onClick={() => actions.setActiveScreen('Today')}
          />
          <NavButton
            label="Journey"
            icon={<FlameIcon />}
            isActive={activeScreen === 'Journey'}
            onClick={() => actions.setActiveScreen('Journey')}
          />
           <NavButton
            label="Chat"
            icon={<MessageSquareIcon />}
            isActive={activeScreen === 'Chat'}
            onClick={() => actions.setActiveScreen('Chat')}
          />
          <NavButton
            label="Profile"
            icon={<UserIcon />}
            isActive={activeScreen === 'Profile'}
            onClick={() => actions.setActiveScreen('Profile')}
          />
        </div>
      </nav>
    </div>
  );
}

const NavButton: React.FC<{ label: string; icon: React.ReactNode; isActive: boolean; onClick: () => void; }> = ({ label, icon, isActive, onClick }) => (
  <button onClick={onClick} className={`flex flex-col items-center justify-center w-full text-sm font-medium transition-colors ${isActive ? 'text-blue-400' : 'text-gray-400 hover:text-blue-300'}`}>
    <div className={`w-8 h-8 mb-1 flex items-center justify-center`}>
        {icon}
    </div>
    {label}
  </button>
);


export default App;