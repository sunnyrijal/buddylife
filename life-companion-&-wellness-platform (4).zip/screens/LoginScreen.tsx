import React, { useState } from 'react';
import { GoogleIcon } from '@/components/icons/Icons';

interface LoginScreenProps {
  onLogin: (username: string) => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      onLogin(username.trim());
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-900 px-4">
      <div className="w-full max-w-md text-center">
        <div className="mb-8">
            <span className="text-6xl" role="img" aria-label="Sparkles">✨</span>
            <h1 className="text-4xl font-extrabold text-white mt-4">Life Companion</h1>
            <p className="text-lg text-gray-300 mt-2">A personalized space to grow, reflect, and thrive.</p>
        </div>
        <div className="bg-gray-800 p-8 border border-gray-700">
          <h2 className="text-2xl font-bold text-gray-100 mb-6">Sign In</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Enter your name to create or load an account"
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 text-lg text-center text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              required
            />
             <button
              type="submit"
              disabled={!username.trim()}
              className="w-full py-3 px-4 bg-blue-600 text-white font-bold text-lg hover:bg-blue-700 transition-colors disabled:bg-blue-800 disabled:cursor-not-allowed"
            >
              Sign In / Register
            </button>
          </form>
          <div className="my-6 flex items-center">
            <div className="flex-grow border-t border-gray-600"></div>
            <span className="flex-shrink mx-4 text-gray-400">OR</span>
            <div className="flex-grow border-t border-gray-600"></div>
          </div>
          <button
            onClick={() => onLogin('Demo User')}
            className="w-full py-3 px-4 bg-white text-gray-800 font-bold text-lg hover:bg-gray-200 transition-colors flex items-center justify-center gap-2"
          >
            <GoogleIcon className="w-6 h-6" />
            Sign In with Google
          </button>
        </div>
      </div>
    </div>
  );
};