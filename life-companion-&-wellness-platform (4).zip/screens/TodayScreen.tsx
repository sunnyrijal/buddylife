import React, { useEffect, useState } from 'react';
import { AppState, SocialContext, Suggestion, TimeAvailability } from '@/types';
import { useAppStore } from '@/hooks/useAppStore';
import { ProgressCard } from '@/components/ProgressCard';
import { MoodDropdown } from '@/components/MoodDropdown';
import { BookOpenIcon, CalendarHeartIcon, HeartIcon, LightbulbIcon, LoaderIcon, MapPinIcon, PodcastIcon, UserIcon, UsersIcon, YoutubeIcon, SpotifyIcon } from '@/components/icons/Icons';
import { WeeklySurveyModal } from '@/components/WeeklySurveyModal';

type TodayScreenProps = {
    state: AppState;
    actions: ReturnType<typeof useAppStore>['actions'];
}

const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good Morning";
    if (hour < 18) return "Good Afternoon";
    return "Good Evening";
}

const SuggestionIcon = ({ icon, themeColor }: { icon: Suggestion['icon'], themeColor: string }) => {
    const className = `w-5 h-5 ${themeColor}`;
    switch (icon) {
        case 'Book': return <BookOpenIcon className={className} />;
        case 'Podcast': return <PodcastIcon className={className} />;
        case 'YouTube': return <YoutubeIcon className={className} />;
        case 'Local': return <MapPinIcon className={className} />;
        case 'Inventory': return <HeartIcon className={className} />;
        case 'Spotify': return <SpotifyIcon className={className} />;
        case 'DateNight': return <CalendarHeartIcon className={className} />;
        default: return <LightbulbIcon className={className} />;
    }
}

export const TodayScreen: React.FC<TodayScreenProps> = ({ state, actions }) => {
    const { userProfile, currentMood, socialContext, isLoading, currentTimeAvailability, isDateNightMode } = state;
    const { setMood, setSocialContext, fetchSuggestions, completeNudge, fetchDailyRefresh, completeDailyRefresh, fetchWeeklySurvey, submitWeeklySurvey, setTimeAvailability, toggleDateNightMode } = actions;
    const [dailyRefreshAnswered, setDailyRefreshAnswered] = useState(false);
    const [userDailyAnswer, setUserDailyAnswer] = useState('');
    const [isSurveyModalOpen, setSurveyModalOpen] = useState(false);

    useEffect(() => {
        if (currentMood && socialContext && currentTimeAvailability) {
            fetchSuggestions();
        }
    }, [currentMood, socialContext, currentTimeAvailability, isDateNightMode]);
    
    useEffect(() => {
        fetchDailyRefresh();
    }, []);
    
    const handleStartSurvey = () => {
        fetchWeeklySurvey().then(() => {
            setSurveyModalOpen(true);
        });
    };

    const handleSubmitSurvey = (answers: Record<string, string>) => {
        submitWeeklySurvey(answers);
        setSurveyModalOpen(false);
    };

    const hasSuggestions = state.inventorySuggestions.length > 0 || state.externalContentSuggestions.length > 0 || state.localActivitySuggestions.length > 0;
    const today = new Date().toISOString().split('T')[0];
    const habitsCompletedToday = state.habits.filter(h => h.completions.some(c => c.date === today)).length;

    const handleSubmitDailyRefresh = (e: React.FormEvent) => {
        e.preventDefault();
        completeDailyRefresh();
        setDailyRefreshAnswered(true);
    }

    return (
        <div className="space-y-4 pb-24">
            <header>
                <p className="text-lg text-gray-400">{getGreeting()}</p>
                <h1 className="text-4xl font-bold text-white">{userProfile.username}</h1>
            </header>
            
             {state.isSurveyDue && (
                <div className="bg-gradient-to-r from-blue-600 to-indigo-500 p-4 text-white flex justify-between items-center">
                    <div>
                        <h3 className="font-bold">Weekly Check-in!</h3>
                        <p className="text-sm opacity-90">Help us get to know you better.</p>
                    </div>
                    <button onClick={handleStartSurvey} className="bg-white/20 px-3 py-1.5 font-semibold hover:bg-white/30">
                        Start
                    </button>
                </div>
            )}

            <ProgressCard profile={userProfile} />

            {state.dailyRefresh && (
                 <div className="bg-gray-800 p-6 border border-gray-700">
                    <div className="flex items-start gap-4">
                        <div className="bg-gray-700 p-3">
                           <LightbulbIcon className="w-6 h-6 text-yellow-400" />
                        </div>
                        <div>
                             <h3 className="text-lg font-bold text-white">Daily Refresh</h3>
                             <p className="mt-1 text-gray-300">{state.dailyRefresh.question}</p>
                             
                             {!dailyRefreshAnswered ? (
                                <form onSubmit={handleSubmitDailyRefresh} className="mt-3 flex gap-2">
                                    <input 
                                        type="text"
                                        value={userDailyAnswer}
                                        onChange={e => setUserDailyAnswer(e.target.value)}
                                        placeholder="Your answer..."
                                        className="flex-grow bg-gray-700 px-3 py-1.5 text-sm border border-gray-600 focus:ring-2 focus:ring-blue-500 focus:outline-none"
                                    />
                                    <button type="submit" className="text-sm font-semibold text-white bg-blue-600 px-3 py-1.5 hover:bg-blue-700">Submit</button>
                                </form>
                             ) : (
                                <div className="mt-3 p-3 bg-gray-700">
                                    <p className="text-sm text-gray-300">Your answer: <span className="font-semibold">{userDailyAnswer || "No answer"}</span></p>
                                    <p className="text-sm text-gray-100">Correct answer: <span className="font-bold text-green-400">{state.dailyRefresh.answer}</span></p>
                                    <p className="text-xs font-bold text-blue-400 mt-1">+25 XP Claimed!</p>
                                </div>
                             )}
                        </div>
                    </div>
                 </div>
            )}

            <div className="bg-gray-800 p-6 space-y-4 border border-gray-700">
                <h2 className="text-xl font-bold text-white">How's your day?</h2>
                <MoodDropdown selectedMood={currentMood} onSelectMood={setMood} />
                <div className="grid grid-cols-3 gap-2">
                    {(Object.values(SocialContext)).map(context => (
                        <button key={context} onClick={() => setSocialContext(context)} className={`flex flex-col items-center justify-center p-3 transition-colors border-2 ${socialContext === context ? 'bg-blue-900/50 border-blue-500' : 'bg-gray-700 border-gray-700 hover:border-gray-600'}`}>
                            {context === SocialContext.JustMe && <UserIcon className={`w-6 h-6 ${socialContext === context ? 'text-blue-400' : 'text-gray-400'}`} />}
                            {context === SocialContext.MyPartner && <HeartIcon className={`w-6 h-6 ${socialContext === context ? 'text-blue-400' : 'text-gray-400'}`} />}
                            {context === SocialContext.WithFriends && <UsersIcon className={`w-6 h-6 ${socialContext === context ? 'text-blue-400' : 'text-gray-400'}`} />}
                            <span className={`text-xs mt-1 font-semibold ${socialContext === context ? 'text-blue-300' : 'text-gray-300'}`}>{context}</span>
                        </button>
                    ))}
                </div>
                <div>
                    <h3 className="text-sm font-semibold text-gray-400 mb-2">How much time do you have?</h3>
                     <div className="grid grid-cols-4 gap-2">
                        {Object.values(TimeAvailability).map(opt => (
                            <button key={opt} onClick={() => setTimeAvailability(opt)} className={`p-2 text-center transition-colors border-2 ${currentTimeAvailability === opt ? 'bg-blue-900/50 border-blue-500' : 'bg-gray-700 border-gray-700 hover:border-gray-600'}`}>
                                <span className={`text-xs font-semibold ${currentTimeAvailability === opt ? 'text-blue-300' : 'text-gray-300'}`}>{opt}</span>
                            </button>
                        ))}
                    </div>
                </div>
                 {socialContext === SocialContext.MyPartner && (
                    <div>
                        <button onClick={toggleDateNightMode} className={`w-full flex items-center justify-center gap-2 p-3 transition-colors border-2 ${isDateNightMode ? 'bg-rose-900/50 border-rose-500' : 'bg-gray-700 border-gray-700 hover:border-gray-600'}`}>
                            <CalendarHeartIcon className={`w-6 h-6 ${isDateNightMode ? 'text-rose-400' : 'text-gray-400'}`} />
                            <span className={`font-semibold ${isDateNightMode ? 'text-rose-300' : 'text-gray-300'}`}>Date Night</span>
                        </button>
                    </div>
                )}
            </div>

            {isLoading && !state.isVoiceSessionActive && (
                 <div className="flex justify-center items-center p-8">
                     <LoaderIcon className="w-8 h-8 text-blue-500"/>
                 </div>
            )}

            {!isLoading && currentMood && currentTimeAvailability && (
                <div className="space-y-4">
                    <h2 className="text-2xl font-bold text-white">Suggestions for a <span className="text-blue-400">{currentMood}</span> day</h2>
                    {hasSuggestions ? (
                        <>
                        <SuggestionSection title={isDateNightMode ? "Date Night Ideas" : "Based on Your Things"} suggestions={state.inventorySuggestions} theme={isDateNightMode ? 'rose' : 'blue'}/>
                        <SuggestionSection title="Content For You" suggestions={state.externalContentSuggestions} theme="teal" />
                        <SuggestionSection title="Get Out There" suggestions={state.localActivitySuggestions} theme="maps" />
                        </>
                    ) : <p className="text-gray-400 text-center py-4">Select a mood, context, and time to get suggestions!</p>}
                </div>
            )}
            
             <div className="bg-gray-800 p-6 space-y-4 border border-gray-700">
                 <h2 className="text-xl font-bold text-white">Quick Nudges</h2>
                 <div className="grid grid-cols-2 gap-3">
                    <NudgeButton onClick={completeNudge} text="Drink Water" icon="💧" />
                    <NudgeButton onClick={completeNudge} text="Deep Breath" icon="🧘" />
                    <NudgeButton onClick={completeNudge} text="Text Friend" icon="💬" />
                    <NudgeButton onClick={completeNudge} text="5-min Tidy" icon="🧹" />
                 </div>
             </div>
             
             <div className="bg-gray-800 p-6 border border-gray-700">
                <h2 className="text-xl font-bold text-white">Today's Habits</h2>
                <p className="text-gray-300 mt-1">{habitsCompletedToday} of {state.habits.length} completed</p>
                <div className="w-full bg-gray-700 h-2.5 mt-3">
                    <div className="bg-green-500 h-2.5" style={{ width: `${state.habits.length > 0 ? (habitsCompletedToday / state.habits.length) * 100 : 0}%` }}></div>
                </div>
             </div>

             {state.currentWeeklySurvey && (
                <WeeklySurveyModal
                    isOpen={isSurveyModalOpen}
                    onClose={() => setSurveyModalOpen(false)}
                    onSubmit={handleSubmitSurvey}
                    survey={state.currentWeeklySurvey}
                    isLoading={state.isLoading}
                />
            )}
        </div>
    );
};

const SuggestionSection = ({ title, suggestions, theme }: { title: string, suggestions: Suggestion[], theme: 'blue' | 'rose' | 'teal' | 'maps' }) => {
    if (suggestions.length === 0) return null;
    const themeClasses = {
        blue: { bg: 'bg-gray-800', iconBg: 'bg-blue-900/50', iconText: 'text-blue-400', link: 'text-blue-500' },
        rose: { bg: 'bg-gray-800', iconBg: 'bg-rose-900/50', iconText: 'text-rose-400', link: 'text-rose-500' },
        teal: { bg: 'bg-gray-800', iconBg: 'bg-teal-900/50', iconText: 'text-teal-400', link: 'text-teal-500' },
        maps: { bg: 'bg-gray-800', iconBg: 'bg-rose-900/50', iconText: 'text-rose-400', link: 'text-teal-400' },
    }
    const currentTheme = themeClasses[theme];
    
    return (
        <div>
            <h3 className="text-lg font-semibold text-gray-300 mb-3">{title}</h3>
            <div className="space-y-3">
                {suggestions.map((s, i) => (
                    <div key={i} className={`${currentTheme.bg} p-4 flex items-start gap-4 border border-gray-700`}>
                        <div className={`${currentTheme.iconBg} p-3`}>
                           <SuggestionIcon icon={s.icon} themeColor={currentTheme.iconText} />
                        </div>
                        <div className="flex-1">
                            <h4 className="font-bold text-white">{s.title}</h4>
                            <p className="text-sm text-gray-400">{s.description}</p>
                            {s.link && <a href={s.link} target="_blank" rel="noopener noreferrer" className={`text-xs ${currentTheme.link} hover:underline mt-1 inline-block`}>Learn more</a>}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

const NudgeButton = ({ text, icon, onClick }: { text: string, icon: string, onClick: () => void }) => (
    <button onClick={onClick} className="bg-gray-700/50 p-3 text-left hover:bg-gray-700 transition-colors">
        <span className="text-2xl">{icon}</span>
        <p className="font-semibold text-sm mt-1 text-gray-200">{text}</p>
    </button>
)
