import React, { useState } from 'react';
import { OnboardingData } from '@/types';
import { LoaderIcon } from '@/components/icons/Icons';

interface OnboardingScreenProps {
  username: string;
  onComplete: (data: OnboardingData) => void;
  isLoading: boolean;
}

const steps = ["Welcome", "Streaming", "Games", "Game Details", "Social", "Hobbies", "Inventory"];
const platformsRequiringInput = ["PC", "PlayStation", "Xbox", "Nintendo Switch", "Mobile Games"];


export const OnboardingScreen: React.FC<OnboardingScreenProps> = ({ username, onComplete, isLoading }) => {
  const [step, setStep] = useState(0);
  const [data, setData] = useState<OnboardingData>({
    streaming: [], games: [], gameListText: '', socialMedia: [], hobbies: [], inventoryText: ''
  });

  const nextStep = () => setStep(s => {
    let nextS = s + 1;
    if (s === 2 && !data.games.some(g => platformsRequiringInput.includes(g))) {
        nextS += 1;
    }
    return Math.min(nextS, steps.length - 1);
  });

  const prevStep = () => setStep(s => {
      let prevS = s - 1;
      if (s === 4 && !data.games.some(g => platformsRequiringInput.includes(g))) {
          prevS -= 1;
      }
      return Math.max(prevS, 0);
  });

  const handleSetData = (newData: Partial<OnboardingData>) => {
      setData(prev => ({...prev, ...newData}));
  }

  const renderStep = () => {
    switch (step) {
      case 0: return <WelcomeStep username={username} onNext={nextStep} />;
      case 1: return <MultiSelectStep title="What do you watch?" category="streaming" options={["Netflix", "Hulu", "Disney+", "YouTube", "Max", "Prime Video"]} data={data} setData={handleSetData} onNext={nextStep} onPrev={prevStep} />;
      case 2: return <MultiSelectStep title="What do you play?" category="games" options={["PC", "PlayStation", "Xbox", "Nintendo Switch", "Mobile Games", "Board Games"]} data={data} setData={handleSetData} onNext={nextStep} onPrev={prevStep} />;
      case 3: return <GameListStep data={data} setData={setData} onNext={nextStep} onPrev={prevStep} />;
      case 4: return <MultiSelectStep title="Where do you connect?" category="socialMedia" options={["Instagram", "TikTok", "X (Twitter)", "Facebook", "Reddit", "Discord"]} data={data} setData={handleSetData} onNext={nextStep} onPrev={prevStep} />;
      case 5: return <TextListStep title="What are your hobbies?" category="hobbies" data={data} setData={setData} onNext={nextStep} onPrev={prevStep} />;
      case 6: return <InventoryStep data={data} setData={setData} onComplete={() => onComplete(data)} onPrev={prevStep} isLoading={isLoading} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 p-4">
      <div className="w-full max-w-xl mx-auto bg-gray-800 p-8 border border-gray-700">
        <div className="mb-6">
          <div className="flex justify-between items-center text-sm text-gray-400">
            <span>Step {step + 1} of {steps.length}</span>
            <span>{steps[step]}</span>
          </div>
          <div className="w-full bg-gray-700 h-2 mt-2">
            <div className="bg-blue-500 h-2 transition-all duration-300" style={{ width: `${((step + 1) / steps.length) * 100}%` }}></div>
          </div>
        </div>
        {renderStep()}
      </div>
    </div>
  );
};


const WelcomeStep = ({ username, onNext }: { username: string, onNext: () => void }) => (
  <div>
    <h2 className="text-3xl font-bold text-white">Hey, {username}!</h2>
    <p className="mt-2 text-gray-300">Let's set up your personal space. This will only take a minute and helps us give you the best suggestions.</p>
    <button onClick={onNext} className="mt-8 w-full py-3 bg-blue-600 text-white font-bold hover:bg-blue-700 transition-all">Get Started</button>
  </div>
);

const MultiSelectStep = ({ title, category, options, data, setData, onNext, onPrev }: any) => {
    const [otherValue, setOtherValue] = useState('');
    const selectedItems = data[category] || [];
    const isOtherSelected = selectedItems.includes('Other');

    const handleSelect = (item: string) => {
        let newSelection = [...selectedItems];
        if(newSelection.includes(item)) {
            newSelection = newSelection.filter(i => i !== item);
        } else {
            newSelection.push(item);
        }
        setData({ [category]: newSelection });
    }

    const handleNext = () => {
        let finalSelection = [...selectedItems];
        if(isOtherSelected) {
            finalSelection = finalSelection.filter(i => i !== 'Other');
            if(otherValue.trim()) {
                finalSelection.push(otherValue.trim());
            }
        }
        setData({ [category]: finalSelection });
        onNext();
    }

    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-4">{title}</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {[...options, "Other"].map((opt: string) => (
                <button 
                    key={opt} 
                    onClick={() => handleSelect(opt)} 
                    className={`p-4 text-center font-semibold transition-all border-2 ${selectedItems.includes(opt) ? 'bg-blue-900/50 border-blue-500 text-blue-300' : 'bg-gray-700 border-gray-700 hover:border-gray-500'}`}
                >
                {opt}
                </button>
            ))}
            </div>

            {isOtherSelected && (
                <div className="mt-4">
                    <input 
                        type="text"
                        value={otherValue}
                        onChange={(e) => setOtherValue(e.target.value)}
                        placeholder="Please specify"
                        className="w-full bg-gray-700 border-2 border-gray-600 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                </div>
            )}

            <div className="flex justify-between mt-8">
            <button onClick={onPrev} className="py-2 px-4 bg-gray-600 font-semibold">Back</button>
            <button onClick={handleNext} className="py-2 px-6 bg-blue-600 text-white font-bold hover:bg-blue-700">Next</button>
            </div>
        </div>
    );
};

const GameListStep = ({ data, setData, onNext, onPrev }: any) => {
    const selectedPlatforms = data.games.filter((g: string) => platformsRequiringInput.includes(g));
    const [gameInputs, setGameInputs] = useState<Record<string, string>>({});

    const handleInputChange = (platform: string, value: string) => {
        setGameInputs(prev => ({ ...prev, [platform]: value }));
    };

    const handleNext = () => {
        const gameList = Object.entries(gameInputs)
            .map(([platform, titles]) => `${platform} games: ${titles}`)
            .join('. ');
        setData((prev: OnboardingData) => ({ ...prev, gameListText: gameList }));
        onNext();
    };

    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-4">What games do you play?</h2>
            <p className="text-sm text-gray-400 mb-4">List some of your favorites on the platforms you selected. Separate them with commas.</p>
            <div className="space-y-4">
                {selectedPlatforms.map((platform: string) => (
                    <div key={platform}>
                        <label className="font-semibold text-gray-200">{platform} Games</label>
                        <input 
                            type="text"
                            value={gameInputs[platform] || ''}
                            onChange={(e) => handleInputChange(platform, e.target.value)}
                            className="mt-1 w-full bg-gray-700 border-2 border-gray-600 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                            placeholder="e.g. Elden Ring, Baldur's Gate 3..."
                        />
                    </div>
                ))}
            </div>
            <div className="flex justify-between mt-8">
                <button onClick={onPrev} className="py-2 px-4 bg-gray-600 font-semibold">Back</button>
                <button onClick={handleNext} className="py-2 px-6 bg-blue-600 text-white font-bold hover:bg-blue-700">Next</button>
            </div>
        </div>
    );
};

const TextListStep = ({ title, category, data, setData, onNext, onPrev }: any) => {
    const [text, setText] = useState(data[category].join(', '));
    const handleNext = () => {
        const hobbiesArray = text.split(',').map(h => h.trim()).filter(Boolean);
        setData((prev: OnboardingData) => ({...prev, [category]: hobbiesArray}));
        onNext();
    }
    return (
        <div>
            <h2 className="text-2xl font-bold text-white mb-4">{title}</h2>
            <p className="text-sm text-gray-400 mb-2">Separate them with commas.</p>
            <input 
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="w-full bg-gray-700 border-2 border-gray-600 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="e.g. Reading, Hiking, Cooking"
            />
            <div className="flex justify-between mt-8">
                <button onClick={onPrev} className="py-2 px-4 bg-gray-600 font-semibold">Back</button>
                <button onClick={handleNext} className="py-2 px-6 bg-blue-600 text-white font-bold hover:bg-blue-700">Next</button>
            </div>
        </div>
    );
};

const InventoryStep = ({ data, setData, onComplete, onPrev, isLoading }: any) => (
  <div>
    <h2 className="text-2xl font-bold text-white">Almost there!</h2>
    <p className="mt-2 text-gray-300">List anything else that's part of your life - favorite foods, pets, tools, etc. Our AI will categorize it for you.</p>
    <textarea
      value={data.inventoryText}
      onChange={(e) => setData((prev: OnboardingData) => ({...prev, inventoryText: e.target.value}))}
      rows={5}
      className="mt-4 w-full bg-gray-700 border-2 border-gray-600 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
      placeholder="e.g. My golden retriever Sparky, a yoga mat, coffee machine, headphones, art supplies..."
    />
    <div className="flex justify-between mt-8">
      <button onClick={onPrev} className="py-2 px-4 bg-gray-600 font-semibold">Back</button>
      <button onClick={onComplete} disabled={isLoading} className="py-3 px-6 bg-green-600 hover:bg-green-700 text-white font-bold flex items-center gap-2 disabled:bg-green-800">
        {isLoading ? <LoaderIcon className="w-5 h-5"/> : null}
        Finish Setup
      </button>
    </div>
  </div>
);