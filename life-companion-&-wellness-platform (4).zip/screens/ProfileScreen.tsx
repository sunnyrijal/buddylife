import React, { useState, useMemo } from 'react';
import { AppState, InventoryItem, InterestLevel, RelationshipStatus } from '@/types';
import { useAppStore } from '@/hooks/useAppStore';
import { ConfirmationDialog } from '@/components/ConfirmationDialog';
import { BulkInventoryModal } from '@/components/BulkInventoryModal';
import { EditInventoryItemModal } from '@/components/EditInventoryItemModal';
import { UpgradeModal } from '@/components/UpgradeModal';
import { SpotifyConnectModal } from '@/components/SpotifyConnectModal';
import { StarIcon, Trash2Icon, EditIcon, PlusCircleIcon, LoaderIcon, XIcon, SpotifyIcon, CheckCircleIcon, Link2Icon, ChevronDownIcon } from '@/components/icons/Icons';
import { ACHIEVEMENTS } from '@/constants';

type ProfileScreenProps = {
    state: AppState;
    actions: ReturnType<typeof useAppStore>['actions'];
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({ state, actions }) => {
    const { userProfile, hobbies, inventory, isLoading } = state;
    const { logout, resetData, upgradeSubscription, addHobby, deleteHobby, processBulkInventory, updateInventoryItem, deleteInventoryItem, exportData, connectSpotify, disconnectSpotify, addFriend, removeFriend, syncWithPartner, removePartner, updateRelationshipStatus } = actions;
    
    const [isResetConfirmOpen, setResetConfirmOpen] = useState(false);
    const [isBulkAddOpen, setBulkAddOpen] = useState(false);
    const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);
    const [itemToDelete, setItemToDelete] = useState<InventoryItem | null>(null);
    const [isUpgradeModalOpen, setUpgradeModalOpen] = useState(false);
    const [isSpotifyModalOpen, setSpotifyModalOpen] = useState(false);

    const longestStreakOverall = useMemo(() => Math.max(0, ...state.habits.map(h => h.longestStreak)), [state.habits]);
    const totalStreakDays = useMemo(() => state.habits.reduce((acc, h) => acc + h.completions.length, 0), [state.habits]);

    return (
        <div className="space-y-4 pb-24">
            <header className="text-center">
                <div className="w-24 h-24 bg-gray-700 mx-auto flex items-center justify-center text-4xl font-bold text-white mb-2">
                    {userProfile.username?.charAt(0).toUpperCase()}
                </div>
                <h1 className="text-3xl font-bold text-white">{userProfile.username}</h1>
                <p className="text-gray-400">Level {userProfile.level}</p>
            </header>
            
            <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-gray-800 p-4 border border-gray-700"><p className="text-2xl font-bold text-white">{totalStreakDays}</p><p className="text-sm text-gray-400">Total Streak Days</p></div>
                <div className="bg-gray-800 p-4 border border-gray-700"><p className="text-2xl font-bold text-white">{longestStreakOverall}</p><p className="text-sm text-gray-400">Longest Streak</p></div>
            </div>

            <CollapsibleSection title="Achievements">
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                    {ACHIEVEMENTS.map(ach => (
                        <div key={ach.id} className={`p-4 text-center border ${userProfile.achievements.includes(ach.id) ? 'bg-gray-700/50 border-blue-500/30' : 'bg-gray-700 opacity-60 border-gray-600'}`}>
                            <StarIcon className={`w-8 h-8 mx-auto ${userProfile.achievements.includes(ach.id) ? 'text-blue-400' : 'text-gray-500'}`} />
                            <p className="text-sm font-bold mt-2 text-gray-200">{ach.name}</p>
                            <p className="text-xs text-gray-400">{ach.description}</p>
                        </div>
                    ))}
                </div>
            </CollapsibleSection>
            
            <CollapsibleSection title="Hobbies"><HobbiesSection hobbies={hobbies} onAddHobby={addHobby} onDeleteHobby={deleteHobby} /></CollapsibleSection>
            <CollapsibleSection title="Inventory"><InventorySection inventory={inventory} isLoading={isLoading} onBulkAdd={() => setBulkAddOpen(true)} onEditItem={setEditingItem} onDeleteItem={setItemToDelete}/></CollapsibleSection>
            <CollapsibleSection title="Social"><SocialSection profile={userProfile} onAddFriend={addFriend} onRemoveFriend={removeFriend} onSyncPartner={syncWithPartner} onRemovePartner={removePartner} onUpdateRelationshipStatus={updateRelationshipStatus}/></CollapsibleSection>
            <CollapsibleSection title="Subscription"><SubscriptionSection profile={userProfile} onUpgrade={() => setUpgradeModalOpen(true)} /></CollapsibleSection>
            <CollapsibleSection title="Connected Accounts"><ConnectedAccountsSection isSpotifyLinked={userProfile.isSpotifyLinked} onConnectSpotify={() => setSpotifyModalOpen(true)} onDisconnectSpotify={disconnectSpotify} /></CollapsibleSection>

            <CollapsibleSection title="Account">
                <div className="flex flex-col gap-2">
                    <button onClick={exportData} className="text-left w-full p-3 bg-gray-800 hover:bg-gray-700 font-semibold text-blue-400 border border-gray-700">Export Data</button>
                    <button onClick={logout} className="text-left w-full p-3 bg-gray-800 hover:bg-gray-700 font-semibold text-yellow-400 border border-gray-700">Logout</button>
                    <button onClick={() => setResetConfirmOpen(true)} className="text-left w-full p-3 bg-gray-800 hover:bg-gray-700 font-semibold text-red-400 border border-gray-700">Reset All Data</button>
                </div>
            </CollapsibleSection>

            <ConfirmationDialog isOpen={isResetConfirmOpen} onClose={() => setResetConfirmOpen(false)} onConfirm={() => { resetData(); setResetConfirmOpen(false); }} title="Reset All Data" message="Are you sure? This will permanently delete all your habits, inventory, and progress." confirmText="Yes, Reset Everything"/>
            <BulkInventoryModal isOpen={isBulkAddOpen} onClose={() => setBulkAddOpen(false)} onConfirm={processBulkInventory} isLoading={isLoading} />
            <EditInventoryItemModal isOpen={!!editingItem} onClose={() => setEditingItem(null)} onSave={updateInventoryItem} item={editingItem} />
            <ConfirmationDialog isOpen={!!itemToDelete} onClose={() => setItemToDelete(null)} onConfirm={() => { if(itemToDelete) deleteInventoryItem(itemToDelete.id); setItemToDelete(null); }} title="Delete Item" message={`Are you sure you want to delete "${itemToDelete?.name}"?`} />
            <UpgradeModal isOpen={isUpgradeModalOpen} onClose={() => setUpgradeModalOpen(false)} onUpgrade={upgradeSubscription} />
            <SpotifyConnectModal isOpen={isSpotifyModalOpen} onClose={() => setSpotifyModalOpen(false)} onConnect={connectSpotify} />
        </div>
    );
};

const CollapsibleSection: React.FC<{ title: string, children: React.ReactNode }> = ({ title, children }) => {
    const [isOpen, setIsOpen] = useState(false);
    return (
        <div className="bg-gray-800 border border-gray-700">
            <button onClick={() => setIsOpen(!isOpen)} className="w-full flex justify-between items-center p-4">
                <h2 className="text-xl font-bold text-gray-200">{title}</h2>
                <ChevronDownIcon className={`w-6 h-6 text-gray-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            {isOpen && (
                <div className="px-4 pb-4 border-t border-gray-700">
                    {children}
                </div>
            )}
        </div>
    );
};

const HobbiesSection = ({ hobbies, onAddHobby, onDeleteHobby }: { hobbies: string[], onAddHobby: (h: string) => void, onDeleteHobby: (h: string) => void }) => {
    const [newHobby, setNewHobby] = useState('');
    const handleAdd = () => { if(newHobby.trim()) { onAddHobby(newHobby.trim()); setNewHobby(''); }};
    return (
        <div className="pt-4">
            <div className="flex flex-wrap gap-2">
                {hobbies.map(hobby => (
                    <div key={hobby} className="flex items-center gap-1 bg-gray-700 text-gray-200 px-3 py-1 text-sm font-semibold">
                        <span>{hobby}</span>
                        <button onClick={() => onDeleteHobby(hobby)} className="text-gray-400 hover:text-white"><XIcon className="w-4 h-4"/></button>
                    </div>
                ))}
            </div>
            <div className="flex gap-2 mt-3">
                <input type="text" value={newHobby} onChange={e => setNewHobby(e.target.value)} placeholder="Add a new hobby" className="flex-1 w-full bg-gray-700 p-2 border-2 border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"/>
                <button onClick={handleAdd} className="p-2 bg-blue-600 hover:bg-blue-700 text-white"><PlusCircleIcon className="w-6 h-6"/></button>
            </div>
        </div>
    );
};

const InventorySection = ({ inventory, onBulkAdd, onEditItem, onDeleteItem, isLoading }: { inventory: InventoryItem[], onBulkAdd: () => void, onEditItem: (i: InventoryItem) => void, onDeleteItem: (i: InventoryItem) => void, isLoading: boolean }) => {
    const [sortKey, setSortKey] = useState<'name' | 'category'>('name');
    const sortedInventory = useMemo(() => [...inventory].sort((a,b) => a[sortKey].localeCompare(b[sortKey])), [inventory, sortKey]);
    
    const interestColor = {
        [InterestLevel.High]: 'text-green-400',
        [InterestLevel.Medium]: 'text-yellow-400',
        [InterestLevel.Low]: 'text-red-400',
    };

    return (
        <div className="pt-4">
            <div className="flex justify-end items-center mb-2">
                <button onClick={onBulkAdd} className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold flex items-center gap-1">
                    <PlusCircleIcon className="w-4 h-4" /> Bulk Add
                </button>
            </div>
            <div className="bg-gray-900/50">
                {isLoading && inventory.length === 0 ? <LoaderIcon className="w-8 h-8 text-blue-500 mx-auto my-8" /> : 
                sortedInventory.length > 0 ? (
                    <ul className="divide-y divide-gray-700 max-h-80 overflow-y-auto">
                        {sortedInventory.map(item => (
                            <li key={item.id} className="flex items-center justify-between p-3">
                                <div>
                                    <p className="font-semibold text-white">{item.name}</p>
                                    <p className="text-xs text-gray-400">{item.category}</p>
                                </div>
                                <div className="flex items-center gap-3">
                                    <span className={`text-xs font-bold ${interestColor[item.interest]}`}>{item.interest}</span>
                                    <button onClick={() => onEditItem(item)}><EditIcon className="w-4 h-4 text-gray-400 hover:text-blue-400"/></button>
                                    <button onClick={() => onDeleteItem(item)}><Trash2Icon className="w-4 h-4 text-gray-400 hover:text-red-400"/></button>
                                </div>
                            </li>
                        ))}
                    </ul>
                ) : <p className="text-center py-4 text-gray-400">Your inventory is empty.</p>
                }
            </div>
        </div>
    );
};

const SocialSection = ({ profile, onAddFriend, onRemoveFriend, onSyncPartner, onRemovePartner, onUpdateRelationshipStatus }: any) => {
    const [usernameInput, setUsernameInput] = useState('');
    
    const handleAdd = () => {
        if (!usernameInput.trim()) return;
        if (profile.relationshipStatus === RelationshipStatus.InARelationship && !profile.partnerUsername) {
            onSyncPartner(usernameInput.trim());
        } else {
            onAddFriend(usernameInput.trim());
        }
        setUsernameInput('');
    };
    
    return (
        <div className='p-4 space-y-4'>
            <div className='text-center p-2 bg-gray-700/50'>
                <p className='text-sm text-gray-400'>Your sync username is:</p>
                <p className='font-mono font-bold text-gray-200 select-all'>{profile.username}</p>
            </div>
             <div>
                <h4 className="font-semibold text-gray-200 mb-2">Relationship</h4>
                <select value={profile.relationshipStatus} onChange={e => onUpdateRelationshipStatus(e.target.value as RelationshipStatus)} className="w-full bg-gray-700 p-2 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500">
                    {Object.values(RelationshipStatus).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                {profile.partnerUsername && (
                    <div className="flex items-center justify-between mt-2 bg-gray-700 p-2">
                       <span className='font-semibold text-red-400'>Partner: {profile.partnerUsername}</span>
                       <button onClick={onRemovePartner}><XIcon className="w-4 h-4 text-red-400"/></button>
                    </div>
                )}
            </div>
            <div>
                 <h4 className="font-semibold text-gray-200 mb-2">Friends</h4>
                 <div className='space-y-2'>
                    {profile.friendUsernames.map((friend: string) => (
                         <div key={friend} className="flex items-center justify-between bg-gray-700 p-2">
                           <span className='font-semibold text-gray-300'>{friend}</span>
                           <button onClick={() => onRemoveFriend(friend)}><XIcon className="w-4 h-4 text-gray-500"/></button>
                        </div>
                    ))}
                 </div>
            </div>
            <div>
                <h4 className="font-semibold text-gray-200 mb-2">Add Partner or Friend</h4>
                <div className="flex gap-2">
                    <input type="text" value={usernameInput} onChange={e => setUsernameInput(e.target.value)} placeholder="Enter username..." className="flex-1 w-full bg-gray-700 p-2 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"/>
                    <button onClick={handleAdd} className="p-2 bg-blue-600 hover:bg-blue-700 text-white"><Link2Icon className="w-6 h-6"/></button>
                </div>
            </div>
        </div>
    )
};

const SubscriptionSection = ({ profile, onUpgrade }: { profile: AppState['userProfile'], onUpgrade: () => void }) => {
    return (
        <div className="bg-gray-800/50 p-4 flex justify-between items-center border border-gray-700">
            <div>
                <p className="font-bold text-lg text-white">{profile.subscriptionTier} Plan</p>
                {profile.subscriptionTier === 'Free' && profile.trialEndDate && (
                    <p className="text-sm text-gray-400">Trial ends in {Math.max(0, Math.ceil((new Date(profile.trialEndDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24)))} days</p>
                )}
            </div>
            {profile.subscriptionTier === 'Free' && (
                <button onClick={onUpgrade} className="px-4 py-2 bg-blue-600 text-white font-bold hover:bg-blue-700 transition-colors">Upgrade</button>
            )}
        </div>
    )
}

const ConnectedAccountsSection = ({ isSpotifyLinked, onConnectSpotify, onDisconnectSpotify }: { isSpotifyLinked: boolean, onConnectSpotify: () => void, onDisconnectSpotify: () => void}) => {
    return (
        <div className="bg-gray-800/50 border border-gray-700">
             <div className="flex justify-between items-center p-3">
                <div className="flex items-center gap-3">
                    <SpotifyIcon className="w-6 h-6 text-[#1DB954]" />
                    <span className="font-semibold text-gray-200">Spotify</span>
                </div>
                {isSpotifyLinked ? (
                    <button onClick={onDisconnectSpotify} className="flex items-center gap-2 text-green-400 font-semibold">
                        <CheckCircleIcon className="w-5 h-5" />
                        <span>Connected</span>
                    </button>
                ) : (
                    <button onClick={onConnectSpotify} className="px-3 py-1.5 bg-[#1DB954] text-white text-sm font-semibold hover:bg-[#1ED760] transition-colors">Connect</button>
                )}
            </div>
        </div>
    );
};