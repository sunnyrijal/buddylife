import React, { useState } from 'react';
import { AppState, Habit, HabitCategory, HabitDifficulty, HabitFrequency } from '@/types';
import { useAppStore } from '@/hooks/useAppStore';
import { FlameIcon, PlusCircleIcon, Trash2Icon, EditIcon, CheckCircleIcon, ClockIcon } from '@/components/icons/Icons';
import { ConfirmationDialog } from '@/components/ConfirmationDialog';
import { XP_PER_LEVEL } from '@/constants';

type JourneyScreenProps = {
    state: AppState;
    actions: ReturnType<typeof useAppStore>['actions'];
}

export const JourneyScreen: React.FC<JourneyScreenProps> = ({ state, actions }) => {
    const [isAddModalOpen, setAddModalOpen] = useState(false);
    const [editingHabit, setEditingHabit] = useState<Habit | null>(null);
    const [habitToDelete, setHabitToDelete] = useState<Habit | null>(null);

    const handleSaveHabit = (habitData: Omit<Habit, 'id' | 'currentStreak' | 'longestStreak' | 'completions' | 'lastCompletionDate'>) => {
        if (editingHabit) {
            actions.updateHabit({ ...editingHabit, ...habitData });
        } else {
            actions.addHabit(habitData);
        }
        setAddModalOpen(false);
        setEditingHabit(null);
    };

    const today = new Date().toISOString().split('T')[0];

    return (
        <div className="space-y-6 pb-24">
            <header>
                <h1 className="text-4xl font-bold text-white">Your Journey</h1>
                <p className="text-lg text-gray-400">Track your habits and watch yourself grow.</p>
            </header>

            <div className="bg-gray-800 p-6 border border-gray-700">
                <div className="flex justify-between items-center">
                    <div>
                        <p className="text-sm font-medium text-gray-400">Level {state.userProfile.level}</p>
                        <p className="text-xs text-gray-400">{state.userProfile.xp} / {XP_PER_LEVEL} XP</p>
                    </div>
                     <div className="flex items-center gap-2 text-orange-500">
                        <FlameIcon className="w-5 h-5"/>
                        <span className="font-bold">{state.userProfile.streakFreezes}</span>
                        <span className="text-sm text-gray-300">Streak Freezes</span>
                     </div>
                </div>
                <div className="w-full bg-gray-700 h-2 mt-2">
                    <div className="bg-blue-500 h-2" style={{ width: `${(state.userProfile.xp / XP_PER_LEVEL) * 100}%` }}></div>
                </div>
            </div>

            <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold text-gray-200">Habits</h2>
                <button onClick={() => { setEditingHabit(null); setAddModalOpen(true); }} className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white font-semibold hover:bg-blue-700 transition-colors">
                    <PlusCircleIcon className="w-5 h-5" />
                    Add Habit
                </button>
            </div>
            
            <div className="space-y-3">
                {state.habits.length > 0 ? state.habits.map((habit: Habit) => (
                    <HabitCard 
                        key={habit.id} 
                        habit={habit} 
                        isCompletedToday={habit.completions.some(c => c.date === today)}
                        onComplete={() => actions.completeHabit(habit.id)}
                        onEdit={() => { setEditingHabit(habit); setAddModalOpen(true); }}
                        onDelete={() => setHabitToDelete(habit)}
                    />
                )) : (
                    <div className="text-center py-10 bg-gray-800 border border-gray-700">
                        <p className="text-gray-400">No habits yet. Add one to start your journey!</p>
                    </div>
                )}
            </div>

            {isAddModalOpen && (
                <AddEditHabitModal
                    isOpen={isAddModalOpen}
                    onClose={() => { setAddModalOpen(false); setEditingHabit(null); }}
                    onSave={handleSaveHabit}
                    habit={editingHabit}
                />
            )}
            
            <ConfirmationDialog 
                isOpen={!!habitToDelete}
                onClose={() => setHabitToDelete(null)}
                onConfirm={() => {
                    if (habitToDelete) {
                        actions.deleteHabit(habitToDelete.id);
                        setHabitToDelete(null);
                    }
                }}
                title="Delete Habit"
                message={`Are you sure you want to delete the habit "${habitToDelete?.name}"? This action cannot be undone.`}
                confirmText="Delete"
            />
        </div>
    );
};


interface HabitCardProps {
    habit: Habit;
    isCompletedToday: boolean;
    onComplete: () => void;
    onEdit: () => void;
    onDelete: () => void;
}

const HabitCard: React.FC<HabitCardProps> = ({ habit, isCompletedToday, onComplete, onEdit, onDelete }) => {
    return (
        <div className="bg-gray-800 p-4 border border-gray-700 flex items-center gap-4">
            <button onClick={onComplete} disabled={isCompletedToday} className={`w-12 h-12 flex-shrink-0 flex items-center justify-center border-4 ${isCompletedToday ? 'bg-green-500 border-green-700' : 'bg-gray-700 border-gray-600 hover:bg-green-900/50'}`}>
                <CheckCircleIcon className={`w-7 h-7 ${isCompletedToday ? 'text-white' : 'text-gray-400'}`} />
            </button>
            <div className="flex-1">
                <h3 className="font-bold text-white">{habit.name}</h3>
                <div className="flex items-center gap-2 flex-wrap text-xs mt-1 text-gray-400">
                    <span className="font-medium">{habit.difficulty}</span>
                    <span>&middot;</span>
                    <span>{habit.category}</span>
                    {habit.reminderTime && <div className="flex items-center gap-1"><ClockIcon className="w-3 h-3"/> {habit.reminderTime}</div>}
                </div>
            </div>
            <div className="flex items-center gap-2 text-orange-500">
                <FlameIcon className="w-5 h-5" />
                <span className="font-bold">{habit.currentStreak}</span>
            </div>
            <div className="flex gap-1">
                 <button onClick={onEdit} className="p-2 text-gray-400 hover:text-blue-400"><EditIcon className="w-4 h-4" /></button>
                 <button onClick={onDelete} className="p-2 text-gray-400 hover:text-red-400"><Trash2Icon className="w-4 h-4" /></button>
            </div>
        </div>
    );
};


const AddEditHabitModal = ({ isOpen, onClose, onSave, habit }: { isOpen: boolean, onClose: () => void, onSave: (data: any) => void, habit: Habit | null }) => {
    const [name, setName] = useState(habit?.name || '');
    const [category, setCategory] = useState(habit?.category || HabitCategory.Health);
    const [difficulty, setDifficulty] = useState(habit?.difficulty || HabitDifficulty.Easy);
    const [frequency, setFrequency] = useState(habit?.frequency || HabitFrequency.Daily);
    const [reminderTime, setReminderTime] = useState(habit?.reminderTime || '');
    
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSave({ name, category, difficulty, frequency, reminderTime });
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <form onSubmit={handleSubmit} className="bg-gray-800 border border-gray-700 shadow-xl w-full max-w-lg p-6 relative">
                 <h2 className="text-2xl font-bold text-white mb-4">{habit ? 'Edit Habit' : 'Add New Habit'}</h2>
                 <div className="space-y-4">
                     <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Habit Name (e.g., Read for 15 minutes)" required className="w-full bg-gray-700 p-3 border border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500"/>
                     <select value={category} onChange={e => setCategory(e.target.value as HabitCategory)} className="w-full bg-gray-700 p-3 border border-gray-600">
                         {Object.values(HabitCategory).map(c => <option key={c} value={c}>{c}</option>)}
                     </select>
                     <select value={difficulty} onChange={e => setDifficulty(e.target.value as HabitDifficulty)} className="w-full bg-gray-700 p-3 border border-gray-600">
                         {Object.values(HabitDifficulty).map(d => <option key={d} value={d}>{d}</option>)}
                     </select>
                     <select value={frequency} onChange={e => setFrequency(e.target.value as HabitFrequency)} className="w-full bg-gray-700 p-3 border border-gray-600">
                         {Object.values(HabitFrequency).map(f => <option key={f} value={f}>{f}</option>)}
                     </select>
                     <input type="time" value={reminderTime} onChange={e => setReminderTime(e.target.value)} className="w-full bg-gray-700 p-3 border border-gray-600"/>
                 </div>
                 <div className="flex justify-end gap-4 mt-6">
                     <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-600 font-semibold">Cancel</button>
                     <button type="submit" className="px-4 py-2 bg-blue-600 text-white font-semibold">Save</button>
                 </div>
            </form>
        </div>
    );
};